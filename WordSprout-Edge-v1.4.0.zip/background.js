"use strict";

importScripts("matcher.js");
const matcher = globalThis.WordSproutMatcher;
const CACHE_LIMIT = 200;
const SELECTION_MENU_ID = "wordsprout-lookup-selection";
let mutationQueue = Promise.resolve();
let cacheQueue = Promise.resolve();
const translationRequests = new Map();
const dictionaryRequests = new Map();
const localDictionary = new Map();
const exampleRequests = new Map();
const exampleCache = new Map();
let translationCooldownUntil = 0;
let menuInitialization;

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(console.error);
  return ensureSelectionMenu().catch(console.error);
});
chrome.runtime.onStartup.addListener(() => ensureSelectionMenu().catch(console.error));

// Also set this after a service worker restart, so an updated extension keeps its toolbar behavior.
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(console.error);
ensureSelectionMenu().catch(console.error);

function ensureSelectionMenu() {
  if (menuInitialization) return menuInitialization;
  const properties = {
    title: "用词芽翻译选中内容",
    contexts: ["selection"],
    enabled: true,
    visible: true
  };
  // Update in place so a worker restart never removes the menu. Callback APIs
  // also work in Edge versions where these methods do not return promises.
  menuInitialization = new Promise((resolve, reject) => {
    chrome.contextMenus.update(SELECTION_MENU_ID, properties, () => {
      if (!chrome.runtime.lastError) return resolve();
      chrome.contextMenus.create({ id: SELECTION_MENU_ID, ...properties }, () => {
        const error = chrome.runtime.lastError;
        if (error) reject(new Error(error.message));
        else resolve();
      });
    });
  }).finally(() => { menuInitialization = null; });
  return menuInitialization;
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== SELECTION_MENU_ID || !tab?.windowId) return;
  const selectedText = String(info.selectionText || "").trim();
  const pendingLookup = {
    text: selectedText.slice(0, 500),
    tooLong: selectedText.length > 500,
    id: `${Date.now()}-${Math.random()}`,
    windowId: tab.windowId
  };
  // Both calls start in the menu-click gesture. The sidebar listens for the
  // session update even when it opens before the write finishes.
  const opening = chrome.sidePanel.open({ windowId: tab.windowId });
  const saving = chrome.storage.session.set({ pendingLookup });
  Promise.allSettled([saving, opening]).then((results) => {
    for (const result of results) if (result.status === "rejected") console.error(result.reason);
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "OPEN_FAVORITE") {
    const key = matcher.keyFor(message.word);
    if (!sender.tab?.windowId || !key) {
      sendResponse({ ok: false, error: "无法定位这条收藏" });
      return false;
    }
    const pendingFavorite = {
      key, id: `${Date.now()}-${Math.random()}`, windowId: sender.tab.windowId
    };
    // Open while the click's user gesture is still active, then notify the panel.
    let opening;
    let saving;
    try {
      opening = chrome.sidePanel.open({ windowId: sender.tab.windowId });
      saving = chrome.storage.session.set({ pendingFavorite });
    } catch (error) {
      sendResponse({ ok: false, error: panelError(error) });
      return false;
    }
    Promise.all([opening, saving])
      .then(() => sendResponse({ ok: true, data: true }))
      .catch((error) => sendResponse({ ok: false, error: panelError(error) }));
    return true;
  }
  if (message?.type === "OPEN_PANEL") {
    // Keep the side-panel call in the click message handler's user gesture.
    if (!sender.tab?.windowId) {
      sendResponse({ ok: false, error: "无法确定当前窗口" });
      return false;
    }
    try {
      chrome.sidePanel.open({ windowId: sender.tab.windowId })
        .then(() => sendResponse({ ok: true, data: true }))
        .catch((error) => sendResponse({ ok: false, error: panelError(error) }));
    } catch (error) {
      sendResponse({ ok: false, error: panelError(error) });
    }
    return true;
  }
  const actions = {
    LOOKUP: () => lookup(message.text ?? message.word),
    CACHE_TRANSLATION: () => cacheTranslation(message.text, message.meaning),
    LOCAL_WORD_DETAILS: () => localWordDetails(message.word),
    WORD_DETAILS: () => wordDetails(message.word),
    EXAMPLE_SENTENCES: () => exampleSentences(message.word),
    TOGGLE_FAVORITE: () => enqueueMutation(() => toggleFavorite(message.entry)),
    ENRICH_FAVORITE: () => enqueueMutation(() => enrichFavorite(message.entry)),
    DELETE_FAVORITES: () => enqueueMutation(() => deleteFavorites(message.words)),
    UPDATE_MEANING: () => enqueueMutation(() => updateMeaning(message.word, message.meaning)),
    UPDATE_NOTE: () => enqueueMutation(() => updateNote(message.word, message.note)),
    DISABLE_PAGE_SELECTION: () => enqueueMutation(() => disablePageSelection(sender)),
    PAUSE_SITE: () => enqueueMutation(() => pauseSite(sender)),
    RESUME_SITE: () => enqueueMutation(() => resumeSite(message.hostname))
  };
  const action = Object.hasOwn(actions, message?.type) ? actions[message.type] : null;
  if (!action) return false;
  Promise.resolve()
    .then(action)
    .then((data) => sendResponse({ ok: true, data }))
    .catch((error) => sendResponse({ ok: false, error: error.message || "操作失败", code: error.code || "" }));
  return true;
});

function panelError(error) {
  return /user gesture/i.test(error?.message || "")
    ? "请点击 Edge 工具栏上的词芽图标打开收藏夹"
    : error?.message || "无法打开侧边栏";
}

function enqueueMutation(task) {
  const result = mutationQueue.then(task);
  mutationQueue = result.catch(() => {});
  return result;
}

async function toggleFavorite(rawEntry) {
  const text = matcher.normalizeQuery(rawEntry?.text ?? rawEntry?.word);
  if (!text) throw new Error("请选择或输入不超过 500 字的英文或中文内容");
  const key = matcher.keyFor(text);
  const { favorites = {} } = await chrome.storage.local.get("favorites");
  if (Object.hasOwn(favorites, key)) {
    delete favorites[key];
    await chrome.storage.local.set({ favorites });
    return { saved: false };
  }
  const entry = {
    word: text,
    text,
    meaning: cleanText(rawEntry.meaning, 1500),
    phonetic: cleanText(rawEntry.phonetic, 80),
    definition: cleanText(rawEntry.definition, 300),
    localSenses: cleanLocalSenses(rawEntry.localSenses),
    localHeadword: matcher.normalizeWord(rawEntry.localHeadword),
    dictionarySenses: cleanDictionarySenses(rawEntry.dictionarySenses),
    audio: cleanAudio(rawEntry.audio),
    note: cleanText(rawEntry.note, 3000),
    direction: matcher.directionFor(text),
    examples: cleanExamples(rawEntry.examples),
    savedAt: Date.now()
  };
  Object.defineProperty(favorites, key, { value: entry, enumerable: true, configurable: true, writable: true });
  await chrome.storage.local.set({ favorites });
  return { saved: true, entry };
}

async function deleteFavorites(words) {
  if (!Array.isArray(words)) throw new Error("无效的删除列表");
  const { favorites = {} } = await chrome.storage.local.get("favorites");
  for (const value of words) {
    if (typeof value === "string") delete favorites[matcher.keyFor(value)];
  }
  await chrome.storage.local.set({ favorites });
  return true;
}

async function enrichFavorite(rawEntry) {
  const text = matcher.normalizeQuery(rawEntry?.text ?? rawEntry?.word);
  if (!text) return null;
  const key = matcher.keyFor(text);
  const { favorites = {} } = await chrome.storage.local.get("favorites");
  if (!Object.hasOwn(favorites, key)) return null;
  const current = favorites[key];
  const updated = { ...current };
  if (!updated.meaning && rawEntry.meaning) updated.meaning = cleanText(rawEntry.meaning, 1500);
  if (!updated.phonetic && rawEntry.phonetic) updated.phonetic = cleanText(rawEntry.phonetic, 80);
  if (!updated.definition && rawEntry.definition) updated.definition = cleanText(rawEntry.definition, 300);
  if (!updated.localSenses?.length && rawEntry.localSenses?.length) updated.localSenses = cleanLocalSenses(rawEntry.localSenses);
  if (!updated.localHeadword && rawEntry.localHeadword) updated.localHeadword = matcher.normalizeWord(rawEntry.localHeadword);
  if (!updated.dictionarySenses?.length && rawEntry.dictionarySenses?.length) updated.dictionarySenses = cleanDictionarySenses(rawEntry.dictionarySenses);
  if (!updated.audio?.length && rawEntry.audio?.length) updated.audio = cleanAudio(rawEntry.audio);
  if (rawEntry.examples?.length) updated.examples = cleanExamples([...(updated.examples || []), ...rawEntry.examples]);
  if (JSON.stringify(updated) !== JSON.stringify(current)) {
    favorites[key] = updated;
    await chrome.storage.local.set({ favorites });
  }
  return updated;
}

async function updateMeaning(word, meaning) {
  const key = matcher.keyFor(word);
  const value = cleanText(meaning, 1500);
  if (!value) throw new Error("请输入译文");
  const { favorites = {} } = await chrome.storage.local.get("favorites");
  if (!Object.hasOwn(favorites, key)) throw new Error("单词未收藏");
  favorites[key] = { ...favorites[key], meaning: value };
  await chrome.storage.local.set({ favorites });
  return favorites[key];
}

async function updateNote(word, note) {
  const key = matcher.keyFor(word);
  const value = cleanText(note, 3000);
  const { favorites = {} } = await chrome.storage.local.get("favorites");
  if (!Object.hasOwn(favorites, key)) throw new Error("内容未收藏");
  favorites[key] = { ...favorites[key], note: value };
  await chrome.storage.local.set({ favorites });
  return favorites[key];
}

async function pauseSite(sender) {
  const hostname = new URL(sender.tab?.url || sender.url || "").hostname.toLowerCase();
  if (!hostname) throw new Error("无法确定当前网站");
  const { pausedSites = {} } = await chrome.storage.local.get("pausedSites");
  Object.defineProperty(pausedSites, hostname, { value: true, enumerable: true, configurable: true, writable: true });
  await chrome.storage.local.set({ pausedSites });
  return hostname;
}

async function disablePageSelection(sender) {
  const key = matcher.pageKeyFor(sender.url || "");
  if (!key) throw new Error("无法确定当前网页");
  const { disabledSelectionPages = {} } = await chrome.storage.local.get("disabledSelectionPages");
  Object.defineProperty(disabledSelectionPages, key, { value: true, enumerable: true, configurable: true, writable: true });
  await chrome.storage.local.set({ disabledSelectionPages });
  return key;
}

async function resumeSite(rawHostname) {
  const hostname = String(rawHostname || "").toLowerCase();
  if (!/^[a-z0-9.-]+$/.test(hostname)) throw new Error("无效的网站域名");
  const { pausedSites = {} } = await chrome.storage.local.get("pausedSites");
  delete pausedSites[hostname];
  await chrome.storage.local.set({ pausedSites });
  return hostname;
}

function cleanText(value, maxLength) {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : "";
}

function cleanExamples(value) {
  return Array.isArray(value)
    ? [...new Set(value.filter((item) => typeof item === "string").map((item) => item.trim()).filter(Boolean))].slice(0, 12).map((item) => item.slice(0, 500))
    : [];
}

function cleanLocalSenses(value) {
  return matcher.groupSenses(value).slice(0, 10).map((group) => ({
    partOfSpeech: cleanText(group.partOfSpeech, 20),
    meanings: Array.isArray(group.meanings) ? group.meanings.slice(0, 24).map((item) => cleanText(item, 150)).filter(Boolean) : []
  })).filter((group) => group.meanings.length);
}

function cleanDictionarySenses(value) {
  return Array.isArray(value) ? value.slice(0, 20).map((group) => ({
    partOfSpeech: cleanText(group.partOfSpeech, 30),
    definitions: Array.isArray(group.definitions) ? group.definitions.slice(0, 40).map((item) => ({
      definition: cleanText(item.definition, 300), example: cleanText(item.example, 500)
    })).filter((item) => item.definition) : []
  })).filter((group) => group.definitions.length) : [];
}

function cleanAudio(value) {
  return Array.isArray(value) ? [...new Set(value.filter((item) => typeof item === "string")
    .map((item) => item.startsWith("//") ? `https:${item}` : item)
    .filter((item) => /^https:\/\//.test(item)))].slice(0, 4) : [];
}

async function lookup(rawText) {
  const text = matcher.normalizeQuery(rawText);
  if (!text) throw new Error("请选择或输入不超过 500 字的英文或中文内容");
  const key = matcher.keyFor(text);
  const { lookupCache = {} } = await chrome.storage.local.get("lookupCache");
  const cached = Object.hasOwn(lookupCache, key) ? lookupCache[key]?.entry : null;
  const singleWord = matcher.normalizeWord(text);
  if (singleWord && !cached?.localSenses?.length) {
    const local = await localWordDetails(singleWord).catch(() => null);
    if (local?.localSenses?.length) {
      return mergeCache(key, {
        text, word: text, meaning: summarizeLocalSenses(local.localSenses),
        phonetic: local.phonetic, localSenses: local.localSenses, localHeadword: local.localHeadword,
        direction: matcher.directionFor(text)
      });
    }
  }
  if (cached?.meaning) return { ...cached, text, word: text };
  return reuse(translationRequests, key, async () => {
    const meaning = await translate(text);
    return mergeCache(key, { text, word: text, meaning, direction: matcher.directionFor(text) });
  });
}

function summarizeLocalSenses(groups) {
  return matcher.compactSenses(groups, 6).map(({ label, meaning }) =>
    `${label === "·" ? "" : `${label} `}${meaning}`).join("；");
}

function cacheTranslation(rawText, rawMeaning) {
  const text = matcher.normalizeQuery(rawText);
  const meaning = cleanText(rawMeaning, 1500);
  if (!text || !meaning) throw new Error("无法缓存空译文");
  const direction = matcher.directionFor(text);
  const expected = direction === "en|zh-CN" ? /[\u3400-\u9fff]/ : /[A-Za-z]/;
  if (!expected.test(meaning)) throw new Error("无效的译文");
  return mergeCache(matcher.keyFor(text), { text, word: text, meaning, direction });
}

async function localWordDetails(rawWord) {
  const word = matcher.normalizeWord(rawWord);
  if (!word) return null;
  if (!chrome.runtime.getURL) return null;
  const letter = word[0];
  if (!localDictionary.has(letter)) {
    const request = fetch(chrome.runtime.getURL(`dictionary/${letter}.json`))
      .then((response) => {
        if (!response.ok) throw new Error("本地词典加载失败");
        return response.json();
      }).catch((error) => {
        localDictionary.delete(letter);
        throw error;
      });
    localDictionary.set(letter, request);
  }
  const shard = await localDictionary.get(letter);
  const headword = Object.hasOwn(shard, word) ? word
    : localBaseCandidates(word).find((candidate) => Object.hasOwn(shard, candidate));
  const entry = headword ? shard[headword] : null;
  // A headword's phonetic spelling should not be shown as the inflected form's pronunciation.
  const phonetic = headword === word ? cleanText(entry?.phonetic, 80) : "";
  return entry ? {
    phonetic: phonetic && !phonetic.startsWith("/") && !phonetic.startsWith("[") ? `/${phonetic}/` : phonetic,
    localSenses: cleanLocalSenses(entry.senses), localHeadword: headword
  } : null;
}

function localBaseCandidates(word) {
  const candidates = [];
  const add = (base) => {
    if (base !== word && matcher.formsFor(base).has(word) && !candidates.includes(base)) candidates.push(base);
  };
  if (word.endsWith("ies") || word.endsWith("ied")) add(`${word.slice(0, -3)}y`);
  if (word.endsWith("ing")) {
    const stem = word.slice(0, -3);
    add(stem);
    add(`${stem}e`);
    if (stem.at(-1) === stem.at(-2)) add(stem.slice(0, -1));
  }
  if (word.endsWith("ed")) {
    const stem = word.slice(0, -2);
    add(stem);
    add(word.slice(0, -1));
    if (stem.at(-1) === stem.at(-2)) add(stem.slice(0, -1));
  }
  if (word.endsWith("ment")) add(word.slice(0, -4));
  if (word.endsWith("ments")) add(word.slice(0, -5));
  for (const suffix of ["ers", "er", "s"]) if (word.endsWith(suffix)) add(word.slice(0, -suffix.length));
  return candidates;
}

async function wordDetails(rawWord) {
  const word = matcher.normalizeWord(rawWord);
  if (!word) throw new Error("音标和词典例句仅适用于单个英文单词");
  const { lookupCache = {} } = await chrome.storage.local.get("lookupCache");
  const cached = Object.hasOwn(lookupCache, word) ? lookupCache[word] : null;
  if (cached?.detailsFetched) {
    return {
      phonetic: cached.entry.phonetic || "",
      definition: cached.entry.definition || "",
      examples: cached.entry.examples || [],
      dictionarySenses: cached.entry.dictionarySenses || [],
      audio: cached.entry.audio || []
    };
  }
  return reuse(dictionaryRequests, word, async () => {
    const details = await fetchDictionary(word);
    await mergeCache(word, details, true);
    return details;
  });
}

async function exampleSentences(rawWord) {
  const word = matcher.normalizeWord(rawWord);
  if (!word) return [];
  if (exampleCache.has(word)) return exampleCache.get(word);
  return reuse(exampleRequests, word, async () => {
    const url = new URL("https://api.tatoeba.org/v1/sentences");
    url.searchParams.set("lang", "eng");
    url.searchParams.set("q", word);
    url.searchParams.set("trans:lang", "cmn");
    url.searchParams.set("showtrans:lang", "cmn");
    url.searchParams.set("sort", "words");
    url.searchParams.set("limit", "8");
    const data = await fetchJson(url.href);
    const results = matcher.dedupeBilingualExamples((Array.isArray(data.data) ? data.data : []).flatMap((item) => {
      const chinese = (item.translations || []).find((translation) => translation.lang === "cmn" && translation.script === "Hans")
        || (item.translations || []).find((translation) => translation.lang === "cmn");
      if (!chinese || !item.text || !chinese.text) return [];
      return [{
        text: cleanText(item.text, 500), translation: cleanText(chinese.text, 500),
        id: item.id, author: cleanText(item.owner, 80), license: cleanText(item.license, 50),
        translationAuthor: cleanText(chinese.owner, 80), translationLicense: cleanText(chinese.license, 50)
      }];
    }));
    exampleCache.set(word, results);
    if (exampleCache.size > 100) exampleCache.delete(exampleCache.keys().next().value);
    return results;
  });
}

function reuse(requests, key, task) {
  if (requests.has(key)) return requests.get(key);
  const request = task().finally(() => requests.delete(key));
  requests.set(key, request);
  return request;
}

function mergeCache(key, patch, detailsFetched = false) {
  const result = cacheQueue.then(async () => {
    const { lookupCache = {} } = await chrome.storage.local.get("lookupCache");
    const old = Object.hasOwn(lookupCache, key) ? lookupCache[key] : null;
    const entry = { ...(old?.entry || {}), ...patch };
    Object.defineProperty(lookupCache, key, {
      value: { entry, at: Date.now(), detailsFetched: Boolean(detailsFetched || old?.detailsFetched) },
      enumerable: true, configurable: true, writable: true
    });
    const keys = Object.keys(lookupCache);
    if (keys.length > CACHE_LIMIT) {
      keys.sort((a, b) => lookupCache[a].at - lookupCache[b].at);
      for (const expired of keys.slice(0, keys.length - CACHE_LIMIT)) delete lookupCache[expired];
    }
    await chrome.storage.local.set({ lookupCache });
    return entry;
  });
  cacheQueue = result.catch(() => {});
  return result;
}

async function fetchJson(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 7000);
  try {
    const response = await fetch(url, { signal: controller.signal });
    if (!response.ok) {
      const error = new Error(`HTTP ${response.status}`);
      error.status = response.status;
      throw error;
    }
    return await response.json();
  } finally {
    clearTimeout(timer);
  }
}

async function fetchDictionary(word) {
  const data = await fetchJson(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`);
  if (!Array.isArray(data) || !data.length) throw new Error("词典中没有这个单词");
  const phonetic = cleanText(data.find((item) => item.phonetic)?.phonetic || data.flatMap((item) => item.phonetics || []).find((item) => item.text)?.text, 80);
  const meanings = data.flatMap((item) => item.meanings || []);
  const definitions = meanings.flatMap((item) => item.definitions || []);
  const phonetics = data.flatMap((item) => item.phonetics || []);
  return {
    phonetic,
    definition: cleanText(definitions.find((item) => item.definition)?.definition, 300),
    examples: cleanExamples(definitions.map((item) => item.example)),
    dictionarySenses: cleanDictionarySenses(meanings.map((item) => ({
      partOfSpeech: item.partOfSpeech,
      definitions: item.definitions || []
    }))),
    audio: cleanAudio(phonetics.map((item) => item.audio))
  };
}

async function translate(text) {
  const direction = matcher.directionFor(text);
  const chunks = splitForApi(text);
  const results = await Promise.all(chunks.map((chunk) => translateChunk(chunk, direction)));
  return cleanText(results.join(" "), 1500);
}

function splitForApi(text) {
  const encoder = new TextEncoder();
  const chunks = [];
  let remaining = text;
  while (encoder.encode(remaining).length > 500) {
    let bytes = 0;
    let cut = 0;
    for (const character of remaining) {
      const size = encoder.encode(character).length;
      if (bytes + size > 500) break;
      bytes += size;
      cut += character.length;
    }
    const prefix = remaining.slice(0, cut);
    const boundaries = [...prefix.matchAll(/[。！？.!?；;，,]\s*|\s+/g)];
    const boundary = boundaries.findLast((match) => match.index >= cut / 2);
    const split = boundary ? boundary.index + boundary[0].length : cut;
    chunks.push(remaining.slice(0, split).trim());
    remaining = remaining.slice(split).trimStart();
  }
  if (remaining) chunks.push(remaining);
  return chunks;
}

async function translateChunk(text, direction) {
  if (Date.now() < translationCooldownUntil) throw translationRateLimitError();
  const url = new URL("https://api.mymemory.translated.net/get");
  url.searchParams.set("q", text);
  url.searchParams.set("langpair", direction);
  let data;
  try { data = await fetchJson(url.href); }
  catch (error) {
    if (error.status === 429) throw translationRateLimitError();
    throw error;
  }
  if (Number(data.responseStatus) === 429) throw translationRateLimitError();
  if (Number(data.responseStatus) !== 200) throw new Error("翻译服务暂时不可用");
  const result = cleanText(data.responseData?.translatedText, 1500);
  const expected = direction === "en|zh-CN" ? /[\u3400-\u9fff]/ : /[A-Za-z]/;
  if (!expected.test(result) || result.toLowerCase() === text.toLowerCase()) throw new Error("未取得有效译文，请稍后重试");
  return result;
}

function translationRateLimitError() {
  translationCooldownUntil = Date.now() + 60000;
  const error = new Error("在线翻译请求过多，请稍后重试");
  error.code = "TRANSLATION_RATE_LIMIT";
  return error;
}

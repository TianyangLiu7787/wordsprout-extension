// Use Edge's on-device Translator API when the online translation service is rate limited.
(function (root) {
  "use strict";

  async function translate(text, direction, onStatus = () => {}) {
    const api = root.Translator;
    if (!api?.availability || !api?.create) return "";
    const options = direction === "zh-CN|en"
      ? { sourceLanguage: "zh", targetLanguage: "en" }
      : { sourceLanguage: "en", targetLanguage: "zh" };
    let session;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 30000);
    try {
      const availability = await api.availability(options);
      if (availability === "unavailable") return "";
      onStatus(availability === "available" ? "正在使用浏览器本机翻译…" : "正在准备浏览器本机翻译模型…");
      session = await api.create({ ...options, signal: controller.signal });
      const result = String(await session.translate(text, { signal: controller.signal }) || "").trim();
      const expected = direction === "zh-CN|en" ? /[A-Za-z]/ : /[\u3400-\u9fff]/;
      return expected.test(result) && result.toLowerCase() !== text.toLowerCase() ? result : "";
    } catch {
      return "";
    } finally {
      clearTimeout(timer);
      try { session?.destroy?.(); } catch {}
    }
  }

  root.WordSproutBrowserTranslate = { translate };
  if (typeof module !== "undefined" && module.exports) module.exports = { translate };
})(globalThis);

(function (root) {
  "use strict";

  const LETTER_OR_NUMBER = /[\p{L}\p{N}_]/u;
  const TOKEN = /[A-Za-z]+/g;
  const PHRASE_PATTERNS = new WeakMap();

  function normalizeWord(value) {
    const word = String(value || "").trim().toLowerCase();
    return /^[a-z]{1,64}$/.test(word) ? word : "";
  }

  function normalizeQuery(value) {
    const text = String(value ?? "").replace(/\s+/g, " ").trim();
    return text.length <= 500 && /[A-Za-z\u3400-\u9fff]/.test(text) ? text : "";
  }

  function keyFor(value) {
    return normalizeQuery(value).toLowerCase();
  }

  function directionFor(value) {
    const firstLetter = normalizeQuery(value).match(/[A-Za-z\u3400-\u9fff]/)?.[0] || "";
    return /[\u3400-\u9fff]/.test(firstLetter) ? "zh-CN|en" : "en|zh-CN";
  }

  function pageKeyFor(value) {
    try {
      const url = new URL(String(value || ""));
      if (url.protocol !== "http:" && url.protocol !== "https:") return "";
      const route = /^#(?:\/|!\/)/.test(url.hash) ? url.hash : "";
      return url.origin + url.pathname + url.search + route;
    } catch {
      return "";
    }
  }

  // Match whole English tokens and a small, predictable set of word forms.
  // Keeping the variants explicit avoids highlighting unrelated longer words.
  function formsFor(value) {
    const word = normalizeWord(value);
    if (!word) return new Set();
    const forms = new Set([word, word + "s", word + "er", word + "ers"]);

    if (word.endsWith("e")) {
      forms.add(word + "d");
      forms.add(word.slice(0, -1) + "ing");
      forms.add(word + "r");
      forms.add(word + "rs");
    } else {
      forms.add(word + "ing");
      if (!word.endsWith("y") || /[aeiou]y$/.test(word)) forms.add(word + "ed");
    }
    if (word.endsWith("y") && !/[aeiou]y$/.test(word)) {
      const stem = word.slice(0, -1);
      forms.add(stem + "ies");
      forms.add(stem + "ied");
    }
    if (word.length >= 3 && word.length <= 5 && /[^aeiou][aeiou][^aeiouwxy]$/.test(word)) {
      const last = word.at(-1);
      forms.add(word + last + "ed");
      forms.add(word + last + "ing");
      forms.add(word + last + "er");
    }
    // Common derivation used by words such as develop → development.
    if (word.length >= 5) {
      forms.add(word + "ment");
      forms.add(word + "ments");
    }
    return forms;
  }

  function buildIndex(words) {
    const index = new Map();
    const phrases = [];
    for (const value of words) {
      const word = normalizeWord(value);
      if (word) {
        for (const form of formsFor(word)) {
          // Prefer an exact saved word when two saved words share a form.
          if (!index.has(form) || form === word) index.set(form, word);
        }
        continue;
      }
      const phrase = keyFor(value);
      if (!phrase.includes(" ") || !/[a-z]/.test(phrase) || /[\u3400-\u9fff]/u.test(phrase)) continue;
      const pattern = phrase.split(" ")
        .map((part) => part.replace(/[\\^$.*+?()[\]{}|]/g, "\\$&")).join("\\s+");
      index.set(phrase, phrase);
      phrases.push({ savedWord: phrase, firstWord: phrase.split(" ")[0], regex: new RegExp(pattern, "gi") });
    }
    PHRASE_PATTERNS.set(index, phrases);
    return index;
  }

  function findMatches(text, index) {
    const input = String(text ?? "");
    const matches = [];
    const phrases = PHRASE_PATTERNS.get(index) || [];
    const lowerInput = phrases.length ? input.toLowerCase() : "";
    for (const { savedWord, firstWord, regex } of phrases) {
      if (input.length < savedWord.length || !lowerInput.includes(firstWord)) continue;
      regex.lastIndex = 0;
      for (const match of input.matchAll(regex)) {
        const start = match.index;
        const end = start + match[0].length;
        if (start > 0 && LETTER_OR_NUMBER.test(input[start - 1])) continue;
        if (end < input.length && LETTER_OR_NUMBER.test(input[end])) continue;
        matches.push({ start, end, savedWord, text: match[0] });
      }
    }
    TOKEN.lastIndex = 0;
    for (const match of input.matchAll(TOKEN)) {
      const start = match.index;
      const end = start + match[0].length;
      if (start > 0 && LETTER_OR_NUMBER.test(input[start - 1])) continue;
      if (end < input.length && LETTER_OR_NUMBER.test(input[end])) continue;
      const savedWord = index.get(match[0].toLowerCase());
      if (savedWord) matches.push({ start, end, savedWord, text: match[0] });
    }
    matches.sort((a, b) => a.start - b.start || b.end - a.end);
    const chosen = [];
    let end = 0;
    for (const match of matches) {
      if (match.start < end) continue;
      chosen.push(match);
      end = match.end;
    }
    return chosen;
  }

  function senseKey(value) {
    return String(value || "").normalize("NFKC")
      .replace(/^\s*(?:\[[^\]]{1,12}\]|【[^】]{1,12}】)\s*/u, "")
      .replace(/[，,；;。.!?？！、\s]+/gu, "").toLowerCase();
  }

  function groupSenses(senses) {
    const groups = new Map();
    for (const item of Array.isArray(senses) ? senses : []) {
      const pos = String(item?.partOfSpeech || "其他").trim().toLowerCase().replace(/\.$/, "") || "其他";
      if (!groups.has(pos)) groups.set(pos, { partOfSpeech: pos, meanings: [], keys: new Set() });
      const group = groups.get(pos);
      for (const rawMeaning of Array.isArray(item?.meanings) ? item.meanings : []) {
        const meaning = String(rawMeaning || "").trim();
        const key = senseKey(meaning);
        if (!key || group.keys.has(key)) continue;
        group.keys.add(key);
        group.meanings.push(meaning);
      }
    }
    const knownKeys = new Set([...groups.values()]
      .filter((group) => group.partOfSpeech !== "其他")
      .flatMap((group) => group.meanings.map(senseKey)));
    if (groups.has("其他")) {
      groups.get("其他").meanings = groups.get("其他").meanings
        .filter((meaning) => !knownKeys.has(senseKey(meaning)));
    }
    return [...groups.values()].filter((group) => group.meanings.length)
      .map(({ partOfSpeech, meanings }) => ({ partOfSpeech, meanings }));
  }

  function partOfSpeechLabel(partOfSpeech) {
    const labels = { a: "adj.", adj: "adj.", ad: "adv.", adv: "adv.", int: "interj." };
    return labels[partOfSpeech] || (partOfSpeech === "其他" ? "其他" : `${partOfSpeech}.`);
  }

  function compactSenses(senses, limit = 3) {
    const groups = groupSenses(senses);
    const ordered = [];
    const longest = Math.max(0, ...groups.map((group) => group.meanings.length));
    for (let index = 0; index < longest; index++) {
      for (const group of groups) if (group.meanings[index]) {
        ordered.push({ pos: group.partOfSpeech, meaning: group.meanings[index] });
      }
    }
    const unique = new Map();
    for (const { pos, meaning } of ordered) {
      const key = senseKey(meaning);
      if (!unique.has(key)) unique.set(key, { meaning, parts: new Set() });
      const parts = unique.get(key).parts;
      if (pos !== "其他") { parts.delete("其他"); parts.add(pos); }
      else if (!parts.size) parts.add(pos);
    }
    return [...unique.values()].slice(0, limit).map(({ meaning, parts }) => ({
      label: [...parts].filter((part) => part !== "其他").map(partOfSpeechLabel).join("/") || "·",
      meaning
    }));
  }

  function cardSenses(senses, limit = 3) {
    const grouped = groupSenses(senses);
    const primary = grouped.filter((group) => group.partOfSpeech !== "其他");
    const groups = primary.length ? primary : grouped;
    const rows = groups.map((group) => ({
      label: group.partOfSpeech === "其他" ? "释义" : partOfSpeechLabel(group.partOfSpeech),
      meanings: []
    }));
    const seen = new Set();
    let count = 0;
    const longest = Math.max(0, ...groups.map((group) => group.meanings.length));
    for (let index = 0; index < longest && count < limit; index++) {
      for (let groupIndex = 0; groupIndex < groups.length && count < limit; groupIndex++) {
        const meaning = groups[groupIndex].meanings[index];
        const key = senseKey(meaning);
        if (!key || seen.has(key)) continue;
        seen.add(key);
        rows[groupIndex].meanings.push(meaning);
        count++;
      }
    }
    return rows.filter((row) => row.meanings.length)
      .map((row) => ({ label: row.label, meaning: row.meanings.join("；") }));
  }

  function dedupeBilingualExamples(examples, limit = 5) {
    const result = [];
    const seenEnglish = new Set();
    const seenChinese = new Set();
    const keyForSentence = (value) => String(value || "").normalize("NFKC").toLowerCase()
      .replace(/[\p{P}\p{S}\s]+/gu, "");
    for (const example of Array.isArray(examples) ? examples : []) {
      const english = keyForSentence(example?.text);
      const chinese = keyForSentence(example?.translation);
      if (!english || !chinese || seenEnglish.has(english) || seenChinese.has(chinese)) continue;
      seenEnglish.add(english);
      seenChinese.add(chinese);
      result.push(example);
      if (result.length >= limit) break;
    }
    return result;
  }

  const api = { normalizeWord, normalizeQuery, keyFor, pageKeyFor, directionFor, formsFor, buildIndex, findMatches, groupSenses, compactSenses, cardSenses, partOfSpeechLabel, dedupeBilingualExamples };
  root.WordSproutMatcher = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(globalThis);

import { getDocument, GlobalWorkerOptions, TextLayer } from "./vendor/package/build/pdf.min.mjs";

GlobalWorkerOptions.workerSrc = new URL("./vendor/package/build/pdf.worker.min.mjs", import.meta.url).href;

const $ = (selector) => document.querySelector(selector);
const fileInput = $("#file-input");
const pageInput = $("#page-number");
const canvas = $("#pdf-canvas");
const textLayer = $("#pdf-text-layer");
const pageShell = $("#page-shell");
let loadingTask = null;
let pdf = null;
let currentPage = 1;
let scale = 1.25;
let busy = false;

$("#choose-file").addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", () => openFile(fileInput.files?.[0]));
$("#previous-page").addEventListener("click", () => renderPage(currentPage - 1));
$("#next-page").addEventListener("click", () => renderPage(currentPage + 1));
pageInput.addEventListener("change", () => renderPage(Number(pageInput.value)));
$("#zoom-out").addEventListener("click", () => changeZoom(-0.2));
$("#zoom-in").addEventListener("click", () => changeZoom(0.2));

const area = $("#reader-area");
area.addEventListener("dragover", (event) => { event.preventDefault(); area.classList.add("dragging"); });
area.addEventListener("dragleave", () => area.classList.remove("dragging"));
area.addEventListener("drop", (event) => {
  event.preventDefault();
  area.classList.remove("dragging");
  openFile(event.dataTransfer?.files?.[0]);
});

async function openFile(file) {
  if (!file || busy) return;
  if (file.type !== "application/pdf" && !/\.pdf$/i.test(file.name)) {
    setStatus("请选择 PDF 文件。");
    return;
  }
  busy = true;
  updateControls();
  setStatus("正在读取 PDF…");
  try {
    await loadingTask?.destroy();
    loadingTask = getDocument({
      data: new Uint8Array(await file.arrayBuffer()),
      cMapUrl: new URL("./vendor/package/cmaps/", import.meta.url).href,
      cMapPacked: true,
      standardFontDataUrl: new URL("./vendor/package/standard_fonts/", import.meta.url).href,
      wasmUrl: new URL("./vendor/package/wasm/", import.meta.url).href
    });
    loadingTask.onPassword = (updatePassword) => {
      const password = prompt("此 PDF 需要密码，请输入密码：");
      if (password) updatePassword(password);
      else loadingTask.destroy();
    };
    pdf = await loadingTask.promise;
    currentPage = 1;
    $("#file-name").textContent = file.name;
    $("#page-count").textContent = String(pdf.numPages);
    pageInput.max = String(pdf.numPages);
    $("#reader-empty").hidden = true;
    pageShell.hidden = false;
  } catch (error) {
    pdf = null;
    pageShell.hidden = true;
    $("#reader-empty").hidden = false;
    setStatus(`无法打开 PDF：${error.message || "文件可能已损坏"}`);
  } finally {
    busy = false;
    updateControls();
  }
  if (pdf) renderPage(1);
}

async function renderPage(number) {
  if (!pdf || busy) return;
  if (!Number.isInteger(number) || number < 1 || number > pdf.numPages) {
    pageInput.value = String(currentPage);
    return;
  }
  busy = true;
  updateControls();
  setStatus(`正在渲染第 ${number} 页…`);
  try {
    const page = await pdf.getPage(number);
    const viewport = page.getViewport({ scale });
    const pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.floor(viewport.width * pixelRatio);
    canvas.height = Math.floor(viewport.height * pixelRatio);
    canvas.style.width = `${viewport.width}px`;
    canvas.style.height = `${viewport.height}px`;
    pageShell.style.width = `${viewport.width}px`;
    pageShell.style.height = `${viewport.height}px`;
    textLayer.replaceChildren();
    textLayer.style.setProperty("--total-scale-factor", String(viewport.scale));
    const transform = pixelRatio === 1 ? undefined : [pixelRatio, 0, 0, pixelRatio, 0, 0];
    await page.render({ canvas, canvasContext: canvas.getContext("2d", { alpha: false }), viewport, transform }).promise;
    await new TextLayer({ textContentSource: page.streamTextContent(), container: textLayer, viewport }).render();
    currentPage = number;
    pageInput.value = String(number);
    $("#zoom-label").textContent = `${Math.round(scale * 100)}%`;
    setStatus(`第 ${number} / ${pdf.numPages} 页 · 划选文字可翻译并收藏。`);
  } catch (error) {
    setStatus(`第 ${number} 页渲染失败：${error.message || "请重试"}`);
  } finally {
    busy = false;
    updateControls();
  }
}

function changeZoom(delta) {
  if (!pdf || busy) return;
  const next = Math.round((scale + delta) * 100) / 100;
  if (next < 0.65 || next > 2.45) return;
  scale = next;
  renderPage(currentPage);
}

function updateControls() {
  $("#choose-file").disabled = busy;
  fileInput.disabled = busy;
  pageInput.disabled = !pdf || busy;
  $("#previous-page").disabled = !pdf || busy || currentPage <= 1;
  $("#next-page").disabled = !pdf || busy || currentPage >= pdf.numPages;
  $("#zoom-out").disabled = !pdf || busy || scale <= 0.65;
  $("#zoom-in").disabled = !pdf || busy || scale >= 2.45;
}

function setStatus(message) { $("#reader-status").textContent = message; }

document.documentElement.dataset.wordsproutPdfReady = "true";

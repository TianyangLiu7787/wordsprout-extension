(function () {
  "use strict";

  const matcher = globalThis.WordSproutMatcher;
  const FONT_SIZES = new Set([70, 80, 90, 100, 110, 125, 150]);
  const HIGHLIGHT = "data-wordsprout-highlight";
  const EXCLUDED = "script, style, noscript, input, textarea, select, button, code, pre, [data-wordsprout-root], [data-wordsprout-highlight], [aria-hidden='true']";
  const SELECTION_EXCLUDED = "script, style, noscript, input, textarea, select, button, code, pre, [data-wordsprout-root]";
  const CARD_CSS = `
    :host { all: initial; --font-scale: 1; color: #172d37; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; font-size: calc(14px * var(--font-scale)); line-height: 1.45; }
    *, *::before, *::after { box-sizing: border-box; }
    .card { width: min(300px, calc(100vw - 16px)); max-height: min(450px, calc(100vh - 16px)); overflow: auto; padding: 12px; border: 1px solid #e0e9e4; border-radius: 14px; background: #fff; box-shadow: 0 16px 48px rgba(14, 39, 43, .2); }
    .top { display: flex; justify-content: space-between; align-items: flex-start; gap: 8px; }
    .word { margin: 0; overflow-wrap: anywhere; font-size: calc(23px * var(--font-scale)); font-weight: 720; line-height: 1.2; color: #173f37; }
    .word.long { display: -webkit-box; overflow: hidden; font-family: inherit; font-size: calc(15px * var(--font-scale)); line-height: 1.45; -webkit-box-orient: vertical; -webkit-line-clamp: 2; }
    .pronunciation { display: flex; align-items: center; gap: 5px; min-height: 25px; margin-top: 2px; }
    .phonetic { margin: 0; color: #87928e; font-size: calc(12px * var(--font-scale)); }
    .icon-row { display: flex; gap: 4px; flex-shrink: 0; }
    button { cursor: pointer; font: inherit; }
    .icon { display: grid; place-items: center; width: 27px; height: 27px; border: 0; border-radius: 8px; color: #31584f; background: #edf4ef; font-size: 17px; }
    .speak { width: 25px; height: 25px; }
    .icon:hover, .icon:focus-visible { background: #dbece2; outline: none; }
    .meaning { margin: 8px 0 4px; font-size: calc(15px * var(--font-scale)); font-weight: 650; line-height: 1.55; color: #253c38; }
    .definition { margin: 0; color: #73817e; font-size: calc(12px * var(--font-scale)); line-height: 1.5; }
    .note { margin: 7px 0 0; color: #697e75; font-size: calc(12px * var(--font-scale)); }
    .senses { display: grid; gap: 4px; margin-top: 7px; }
    .sense { display: flex; gap: 7px; color: #315548; font-size: calc(13px * var(--font-scale)); line-height: 1.5; }
    .sense strong { flex: none; min-width: 36px; color: #16805b; font-style: italic; }
    .card-example { margin-top: 8px; padding: 8px 9px; border-radius: 9px; background: #f4f7f4; }
    .example-en { margin: 0; color: #344b42; font-size: calc(12px * var(--font-scale)); line-height: 1.55; }
    .example-zh { margin: 4px 0 0; color: #697d71; font-size: calc(11px * var(--font-scale)); line-height: 1.5; }
    .translate-example { margin: 5px 0 0; padding: 0; border: 0; background: none; color: #16805b; font-size: calc(11px * var(--font-scale)); font-weight: 650; }
    .user-note { margin: 8px 0 0; padding: 7px 8px; max-height: 80px; overflow: auto; border-radius: 9px; background: #f2f5ed; color: #485d50; font-size: calc(12px * var(--font-scale)); white-space: pre-wrap; }
    .actions { display: flex; gap: 6px; margin-top: 10px; }
    .save { flex: 1; min-height: 33px; border: 0; border-radius: 9px; background: #167755; color: #fff; font-weight: 650; }
    .save:hover, .save:focus-visible { background: #0c6245; outline: none; }
    .save.saved { background: #e8f3eb; color: #126448; }
    .save.saved:hover { background: #d9ebdf; }
    .panel { min-height: 33px; padding: 0 8px; border: 1px solid #d7e2dc; border-radius: 9px; background: #fff; color: #35584f; font-size: calc(12px * var(--font-scale)); }
    .status { margin: 7px 0 0; color: #b84b3d; font-size: calc(12px * var(--font-scale)); }
    [hidden] { display: none !important; }
  `;

  let favorites = {};
  let index = matcher.buildIndex([]);
  let siteSelectionMuted = false;
  let disabledSelectionPages = {};
  let autoTranslateChinese = false;
  let fontSize = 100;
  const topOrigin = location.ancestorOrigins?.[location.ancestorOrigins.length - 1];
  const hostname = (topOrigin ? new URL(topOrigin).hostname : location.hostname).toLowerCase();
  let host;
  let shadow;
  let current = null;
  let requestId = 0;
  let observer;
  const pendingNodes = new Set();
  let scanTimer;
  const isPdfReader = location.protocol === "chrome-extension:" && location.pathname.endsWith("/pdf-reader.html");

  chrome.storage.local.get(["favorites", "pausedSites", "disabledSelectionPages", "autoTranslateChinese", "fontSize"]).then(({ favorites: stored = {}, pausedSites = {}, disabledSelectionPages: disabledPages = {}, autoTranslateChinese: autoChinese = false, fontSize: storedFontSize = 100 }) => {
    favorites = stored;
    index = matcher.buildIndex(Object.keys(favorites));
    siteSelectionMuted = Boolean(pausedSites[hostname]);
    disabledSelectionPages = disabledPages;
    autoTranslateChinese = Boolean(autoChinese);
    applyFontSize(storedFontSize);
    refreshHighlights();
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.favorites) {
      favorites = changes.favorites.newValue || {};
      index = matcher.buildIndex(Object.keys(favorites));
      refreshHighlights();
      if (current) renderCard();
    }
    if (changes.pausedSites) {
      siteSelectionMuted = Boolean(changes.pausedSites.newValue?.[hostname]);
      if (selectionDisabledHere()) hideCard();
    }
    if (changes.disabledSelectionPages) {
      disabledSelectionPages = changes.disabledSelectionPages.newValue || {};
      if (selectionDisabledHere()) hideCard();
    }
    if (changes.autoTranslateChinese) autoTranslateChinese = Boolean(changes.autoTranslateChinese.newValue);
    if (changes.fontSize) applyFontSize(changes.fontSize.newValue);
  });

  function applyFontSize(value) {
    const size = Number(value);
    fontSize = FONT_SIZES.has(size) ? size : 100;
    host?.style.setProperty("--font-scale", String(fontSize / 100));
  }

  function selectionDisabledHere() {
    const key = matcher.pageKeyFor(location.href);
    return siteSelectionMuted || Boolean(key && disabledSelectionPages[key]);
  }

  chrome.runtime.onMessage?.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "GET_PAGE_CONTEXT") return false;
    sendResponse({ url: location.href });
    return false;
  });

  document.addEventListener("mouseup", (event) => {
    if (selectionDisabledHere() || event.button !== 0) return;
    if (host && event.composedPath().includes(host)) return;
    setTimeout(() => openFromSelection(), 0);
  });

  document.addEventListener("keyup", (event) => {
    if (selectionDisabledHere()) return;
    if (event.key === "Shift" || event.key.startsWith("Arrow")) openFromSelection();
  });

  document.addEventListener("click", (event) => {
    if (host && event.composedPath().includes(host)) return;
    if (window.getSelection()?.toString().trim()) return;
    const target = event.target instanceof Element ? event.target.closest(`[${HIGHLIGHT}]`) : null;
    if (!target) return;
    const savedWord = matcher.keyFor(target.getAttribute(HIGHLIGHT));
    if (!savedWord || !Object.hasOwn(favorites, savedWord)) return;
    event.preventDefault();
    event.stopPropagation();
    send({ type: "OPEN_FAVORITE", word: savedWord }).catch((error) => {
      showCard(target.textContent.trim(), target.getBoundingClientRect(), savedWord);
      setStatus(error.message);
    });
  }, true);

  document.addEventListener("pointerdown", (event) => {
    if (host && !event.composedPath().includes(host)) hideCard();
  });

  function openFromSelection() {
    if (selectionDisabledHere()) return;
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || !selection.rangeCount) return;
    const text = matcher.normalizeQuery(selection.toString());
    if (!text) return;
    if (!autoTranslateChinese && matcher.directionFor(text) === "zh-CN|en") return;
    const range = selection.getRangeAt(0);
    const ancestor = range.commonAncestorContainer;
    if (ancestor.nodeType === Node.ELEMENT_NODE && ancestor.closest?.(SELECTION_EXCLUDED)) return;
    if (ancestor.nodeType === Node.TEXT_NODE && ancestor.parentElement?.closest(SELECTION_EXCLUDED)) return;
    const startElement = range.startContainer.nodeType === Node.TEXT_NODE ? range.startContainer.parentElement : range.startContainer;
    if (startElement?.isContentEditable) return;
    if (isPdfReader && !startElement?.closest?.(".textLayer")) return;
    const rect = range.getBoundingClientRect();
    if (!rect.width && !rect.height) return;
    const key = matcher.keyFor(text);
    showCard(text, rect, index.get(key) || key, extractContextSentence(range));
  }

  function extractContextSentence(range) {
    const element = range.startContainer.nodeType === Node.TEXT_NODE
      ? range.startContainer.parentElement
      : range.startContainer;
    const block = element?.closest?.("p, li, blockquote, td, dd, figcaption, div");
    if (!block || block.closest("[data-wordsprout-root]")) return "";
    const text = block.textContent || "";
    if (text.length > 2000) return "";
    const before = document.createRange();
    before.selectNodeContents(block);
    try { before.setEnd(range.startContainer, range.startOffset); }
    catch { return ""; }
    const offset = before.toString().length;
    const previous = [...text.slice(0, offset).matchAll(/[.!?。！？\n]/g)].at(-1);
    const start = previous ? previous.index + 1 : 0;
    const next = /[.!?。！？\n]/.exec(text.slice(offset));
    const end = next ? offset + next.index + 1 : text.length;
    const sentence = text.slice(start, end).replace(/\s+/g, " ").trim();
    return sentence.length >= 12 && sentence.length <= 300 ? sentence : "";
  }

  function ensureCard() {
    if (host) return;
    host = document.createElement("div");
    host.setAttribute("data-wordsprout-root", "");
    host.style.cssText = "position:fixed!important;z-index:2147483647!important;display:none!important;max-width:calc(100vw - 16px)!important;";
    applyFontSize(fontSize);
    shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `<style>${CARD_CSS}</style>
      <section class="card" role="dialog" aria-label="翻译卡片">
        <div class="top"><h2 class="word"></h2>
        <div class="icon-row"><button class="icon pause" type="button" title="关闭此网页的划词弹卡" aria-label="关闭此网页的划词弹卡">Ⅱ</button><button class="icon close" type="button" title="关闭" aria-label="关闭">×</button></div></div>
        <div class="pronunciation"><p class="phonetic"></p><button class="icon speak" type="button" title="播放读音" aria-label="播放读音">♪</button></div>
        <p class="meaning"></p><div class="senses" hidden></div><p class="definition"></p>
        <div class="card-example" hidden><p class="example-en"></p><p class="example-zh" hidden></p><button class="translate-example" type="button" hidden>翻译本页句子</button></div>
        <p class="note" hidden></p><div class="user-note" hidden></div>
        <div class="actions"><button class="save" type="button"></button><button class="panel" type="button">收藏夹 ↗</button></div>
        <p class="status" role="status" hidden></p>
      </section>`;
    shadow.querySelector(".close").addEventListener("click", hideCard);
    shadow.querySelector(".speak").addEventListener("click", () => {
      const audio = current?.entry?.audio?.length ? current.entry.audio : favorites[current?.favoriteKey]?.audio;
      speak(current?.word, audio);
    });
    shadow.querySelector(".pause").addEventListener("click", async () => {
      try {
        const key = await send({ type: "DISABLE_PAGE_SELECTION" });
        disabledSelectionPages[key] = true;
        hideCard();
      } catch (error) { setStatus(error.message); }
    });
    shadow.querySelector(".save").addEventListener("click", toggleCurrent);
    shadow.querySelector(".translate-example").addEventListener("click", async () => {
      const card = current;
      if (!card?.contextExample) return;
      const button = shadow.querySelector(".translate-example");
      button.disabled = true;
      try {
        const result = await lookupWithFallback(card.contextExample);
        if (current !== card) return;
        card.contextTranslation = result.meaning || "";
        renderCard();
      } catch (error) { if (current === card) setStatus(error.message); }
      finally { button.disabled = false; }
    });
    shadow.querySelector(".panel").addEventListener("click", async () => {
      try {
        await send({ type: "OPEN_PANEL" });
      } catch (error) {
        setStatus(error.message);
      }
    });
    document.documentElement.append(host);
  }

  function showCard(word, rect, favoriteKey, contextExample = "") {
    ensureCard();
    const singleWord = matcher.normalizeWord(word);
    current = {
      word, favoriteKey, contextExample,
      entry: { text: word, word, meaning: "", phonetic: "", definition: "", examples: [], localSenses: [], dictionarySenses: [], audio: [] },
      corpusExample: null, contextTranslation: "",
      loadingTranslation: true, loadingDetails: Boolean(singleWord), error: ""
    };
    host.style.setProperty("display", "block", "important");
    positionCard(rect);
    renderCard();
    const id = ++requestId;
    if (singleWord) {
      send({ type: "LOCAL_WORD_DETAILS", word: singleWord }).then((details) => {
        if (id !== requestId || !current || !details) return;
        current.entry = { ...current.entry, phonetic: current.entry.phonetic || details.phonetic,
          localSenses: details.localSenses || [], localHeadword: details.localHeadword || "" };
        renderCard();
        positionCard(rect);
        enrichCurrentFavorite();
      }).catch(() => {});
    }
    lookupWithFallback(word).then((entry) => {
      if (id !== requestId || !current) return;
      current.entry = {
        ...current.entry, ...entry,
        phonetic: current.entry.phonetic || entry.phonetic || "",
        definition: current.entry.definition || entry.definition || "",
        examples: current.entry.examples.length ? current.entry.examples : entry.examples || [],
        localSenses: current.entry.localSenses.length ? current.entry.localSenses : entry.localSenses || [],
        localHeadword: current.entry.localHeadword || entry.localHeadword || ""
      };
      current.loadingTranslation = false;
      current.error = "";
      renderCard();
      positionCard(rect);
      enrichCurrentFavorite();
    }).catch((error) => {
      if (id !== requestId || !current) return;
      current.loadingTranslation = false;
      current.error = error.message;
      renderCard();
    });
    if (singleWord) {
      send({ type: "EXAMPLE_SENTENCES", word: singleWord }).then((examples) => {
        if (id !== requestId || !current || !Array.isArray(examples)) return;
        const exact = new RegExp(`(^|[^A-Za-z])${singleWord}([^A-Za-z]|$)`, "i");
        current.corpusExample = examples.find((example) => example.text?.length <= 180 && exact.test(example.text)) || null;
        renderCard();
        positionCard(rect);
      }).catch(() => {});
      send({ type: "WORD_DETAILS", word: singleWord }).then((details) => {
        if (id !== requestId || !current) return;
        current.entry = { ...current.entry, ...details };
        current.loadingDetails = false;
        renderCard();
        positionCard(rect);
        enrichCurrentFavorite();
      }).catch(() => {
        if (id !== requestId || !current) return;
        current.loadingDetails = false;
        renderCard();
      });
    }
  }

  function enrichCurrentFavorite() {
    if (!current || current.favoriteKey !== matcher.keyFor(current.word)) return;
    send({ type: "ENRICH_FAVORITE", entry: current.entry }).catch(() => {});
  }

  function positionCard(rect) {
    if (!host) return;
    const width = Math.min(340, window.innerWidth - 16);
    const left = Math.max(8, Math.min(rect.left, window.innerWidth - width - 8));
    const height = host.getBoundingClientRect().height || 210;
    const below = rect.bottom + 9;
    const top = below + height <= window.innerHeight - 8
      ? below
      : Math.max(8, rect.top - height - 9);
    host.style.setProperty("left", `${left}px`, "important");
    host.style.setProperty("top", `${top}px`, "important");
  }

  function hideCard() {
    if (host) host.style.setProperty("display", "none", "important");
    current = null;
    requestId++;
  }

  function renderCard() {
    if (!current || !shadow) return;
    const saved = Object.hasOwn(favorites, current.favoriteKey) ? favorites[current.favoriteKey] : null;
    const entry = current.entry || saved;
    shadow.querySelector(".word").textContent = current.word;
    shadow.querySelector(".word").title = current.word;
    shadow.querySelector(".word").classList.toggle("long", current.word.length > 25 || current.word.includes(" "));
    shadow.querySelector(".phonetic").textContent = entry?.phonetic || saved?.phonetic || "";
    const localSenses = entry?.localSenses?.length ? entry.localSenses : saved?.localSenses || [];
    const meaning = shadow.querySelector(".meaning");
    meaning.hidden = Boolean(localSenses.length);
    meaning.textContent = entry?.meaning || saved?.meaning || (current.loadingTranslation ? "正在翻译…" : "暂无译文");
    const senses = shadow.querySelector(".senses");
    senses.replaceChildren();
    senses.hidden = !localSenses.length;
    for (const item of matcher.cardSenses(localSenses)) {
      const row = document.createElement("div");
      row.className = "sense";
      const pos = document.createElement("strong");
      pos.textContent = item.label;
      const translation = document.createElement("span");
      translation.textContent = item.meaning;
      row.append(pos, translation);
      senses.append(row);
    }
    const definition = shadow.querySelector(".definition");
    definition.hidden = Boolean(localSenses.length);
    definition.textContent = entry?.definition || saved?.definition || "";
    const pageExample = current.contextExample?.length <= 180 ? current.contextExample : "";
    const example = current.contextTranslation ? { text: pageExample, translation: current.contextTranslation, fromPage: true }
      : current.corpusExample || (pageExample ? { text: pageExample, fromPage: true } : null);
    const exampleBox = shadow.querySelector(".card-example");
    exampleBox.hidden = !example;
    shadow.querySelector(".example-en").textContent = example?.text || "";
    const exampleZh = shadow.querySelector(".example-zh");
    exampleZh.hidden = !example?.translation;
    exampleZh.textContent = example?.translation || "";
    shadow.querySelector(".translate-example").hidden = !example?.fromPage || Boolean(current.contextTranslation);
    exampleBox.title = example?.id
      ? `Tatoeba · ${example.author || "匿名"} / ${example.translationAuthor || "匿名"} · ${[example.license, example.translationLicense].filter(Boolean).join(" / ")}`
      : "";
    const note = shadow.querySelector(".note");
    const labels = [];
    if (saved && current.favoriteKey !== matcher.keyFor(current.word)) labels.push(`已按 ${current.favoriteKey} 收藏`);
    const localHeadword = entry?.localHeadword || saved?.localHeadword;
    if (localHeadword && localHeadword !== matcher.normalizeWord(current.word)) labels.push(`释义参考原形 ${localHeadword}`);
    note.hidden = !labels.length;
    note.textContent = labels.join(" · ");
    const userNote = shadow.querySelector(".user-note");
    userNote.hidden = !saved?.note;
    userNote.textContent = saved?.note ? `笔记：${saved.note}` : "";
    const save = shadow.querySelector(".save");
    save.textContent = saved ? "★ 已收藏 · 点击取消" : "☆ 收藏内容";
    save.classList.toggle("saved", Boolean(saved));
    save.disabled = (current.loadingTranslation && !saved && !entry?.definition && !localSenses.length);
    setStatus(current.error && !entry?.meaning && !localSenses.length ? current.error
      : current.loadingTranslation && !localSenses.length ? "正在翻译…"
      : current.loadingDetails ? "正在补充音标和例句…" : "");
  }

  async function toggleCurrent() {
    if (!current || !matcher.normalizeQuery(current.word)
        || (current.loadingTranslation && !current.entry?.definition && !current.entry?.localSenses?.length
          && !Object.hasOwn(favorites, current.favoriteKey))) return;
    const key = current.favoriteKey;
    const saved = Object.hasOwn(favorites, key) ? favorites[key] : null;
    const entry = saved || { ...current.entry, text: current.word, word: current.word };
    if (!saved && current.contextExample && current.contextExample.toLowerCase() !== current.word.toLowerCase()) {
      entry.examples = [current.contextExample, ...(entry.examples || []).filter((example) => example !== current.contextExample)];
    }
    try {
      shadow.querySelector(".save").disabled = true;
      const card = current;
      const result = await send({ type: "TOGGLE_FAVORITE", entry });
      if (!result.saved && current === card && matcher.keyFor(current.word) !== key) {
        current.favoriteKey = matcher.keyFor(current.word);
        renderCard();
      }
      if (result.saved) enrichCurrentFavorite();
      setStatus("");
    } catch (error) {
      setStatus(error.message);
      renderCard();
    }
  }

  function setStatus(value) {
    if (!shadow) return;
    const status = shadow.querySelector(".status");
    status.textContent = value;
    status.hidden = !value;
  }

  function speak(word, audioUrls = []) {
    if (!word) return;
    if (audioUrls?.length) {
      new Audio(audioUrls[0]).play().catch(() => speakWithBrowser(word));
      return;
    }
    speakWithBrowser(word);
  }

  function speakWithBrowser(word) {
    if (!globalThis.speechSynthesis) return;
    speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(word);
    utterance.lang = matcher.directionFor(word) === "zh-CN|en" ? "zh-CN" : "en-US";
    utterance.rate = 0.85;
    speechSynthesis.speak(utterance);
  }

  async function send(message) {
    if (!globalThis.chrome?.runtime?.sendMessage) throw new Error("词芽已更新，请刷新当前网页后重试");
    let response;
    try { response = await chrome.runtime.sendMessage(message); }
    catch (error) {
      if (/extension context invalidated|receiving end does not exist/i.test(error?.message || "")) {
        throw new Error("词芽已更新，请刷新当前网页后重试");
      }
      throw error;
    }
    if (!response?.ok) {
      const error = new Error(response?.error || "操作失败");
      error.code = response?.code;
      throw error;
    }
    return response.data;
  }

  async function lookupWithFallback(text) {
    try { return await send({ type: "LOOKUP", text }); }
    catch (error) {
      if (error.code !== "TRANSLATION_RATE_LIMIT") throw error;
      const meaning = await globalThis.WordSproutBrowserTranslate?.translate(text, matcher.directionFor(text));
      if (!meaning) throw error;
      send({ type: "CACHE_TRANSLATION", text, meaning }).catch(() => {});
      return { text, word: text, meaning, direction: matcher.directionFor(text) };
    }
  }

  function canHighlight(node) {
    const parent = node.parentElement;
    return Boolean(parent && parent.namespaceURI === "http://www.w3.org/1999/xhtml" && !parent.isContentEditable && !parent.closest(EXCLUDED) && node.nodeValue?.trim());
  }

  function highlightTextNode(node) {
    if (!canHighlight(node)) return;
    const value = node.nodeValue;
    const matches = matcher.findMatches(value, index);
    if (!matches.length) return;
    const fragment = document.createDocumentFragment();
    let offset = 0;
    for (const match of matches) {
      if (match.start > offset) fragment.append(document.createTextNode(value.slice(offset, match.start)));
      const mark = document.createElement("span");
      mark.setAttribute(HIGHLIGHT, match.savedWord);
      mark.setAttribute("title", `已收藏：${match.savedWord}`);
      mark.style.cssText = "background:#d9f2b7!important;color:inherit!important;border-radius:3px!important;box-shadow:inset 0 -2px #85bd62!important;cursor:pointer!important;";
      mark.textContent = match.text;
      fragment.append(mark);
      offset = match.end;
    }
    if (offset < value.length) fragment.append(document.createTextNode(value.slice(offset)));
    node.replaceWith(fragment);
  }

  function highlightTree(root) {
    if (!index.size || !root) return;
    if (root.nodeType === Node.TEXT_NODE) {
      highlightTextNode(root);
      return;
    }
    if (root.nodeType !== Node.ELEMENT_NODE || root.closest?.("[data-wordsprout-root]") || root.matches?.(EXCLUDED)) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const node of nodes) highlightTextNode(node);
  }

  function observe() {
    if (!observer) {
      observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          if (mutation.type === "characterData") pendingNodes.add(mutation.target);
          else for (const node of mutation.addedNodes) pendingNodes.add(node);
        }
        clearTimeout(scanTimer);
        scanTimer = setTimeout(scanPending, 160);
      });
    }
    observer.observe(document.documentElement, { subtree: true, childList: true, characterData: true });
  }

  function scanPending() {
    observer?.disconnect();
    const nodes = [...pendingNodes];
    pendingNodes.clear();
    for (const node of nodes) {
      if (!node.isConnected) continue;
      if (node.nodeType === Node.TEXT_NODE && node.parentElement?.hasAttribute(HIGHLIGHT)) {
        const parent = node.parentElement;
        const text = document.createTextNode(parent.textContent);
        parent.replaceWith(text);
        highlightTextNode(text);
      } else highlightTree(node);
    }
    observe();
  }

  function refreshHighlights() {
    clearTimeout(scanTimer);
    pendingNodes.clear();
    observer?.disconnect();
    const restoredParents = new Set();
    for (const mark of document.querySelectorAll(`[${HIGHLIGHT}]`)) {
      restoredParents.add(mark.parentNode);
      mark.replaceWith(document.createTextNode(mark.textContent));
    }
    for (const parent of restoredParents) parent?.normalize?.();
    if (!isPdfReader) {
      highlightTree(document.body);
      observe();
    }
  }
})();

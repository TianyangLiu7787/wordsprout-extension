"use strict";

const matcher = globalThis.WordSproutMatcher;
const FONT_SIZES = new Set([70, 80, 90, 100, 110, 125, 150]);
const state = {
  favorites: {}, pausedSites: {}, disabledSelectionPages: {}, autoTranslateChinese: false, fontSize: 100, selected: new Set(), selecting: false,
  activeWord: null, lookupEntry: null, search: "", locatedFavorite: null, settingsOpen: false, currentPageKey: "",
  noteDraftWord: null, noteDraft: "", noteDirty: false,
  pendingTranslation: false, pendingDetails: false,
  lookupError: "", corpusExamples: []
};
const $ = (selector) => document.querySelector(selector);
let toastTimer;
let lookupVersion = 0;
let pageContextVersion = 0;
let lastPendingId = "";
const windowIdPromise = chrome.windows.getCurrent().then((win) => win.id).catch(() => null);

const favoritesReady = chrome.storage.local.get(["favorites", "pausedSites", "disabledSelectionPages", "autoTranslateChinese", "fontSize"]).then(({ favorites = {}, pausedSites = {}, disabledSelectionPages = {}, autoTranslateChinese = false, fontSize = 100 }) => {
  state.favorites = favorites;
  state.pausedSites = pausedSites;
  state.disabledSelectionPages = disabledSelectionPages;
  state.autoTranslateChinese = Boolean(autoTranslateChinese);
  $("#auto-chinese").checked = state.autoTranslateChinese;
  applyFontSize(fontSize);
  render();
});

chrome.storage.session.get("pendingLookup").then(({ pendingLookup }) => consumePending(pendingLookup));
chrome.storage.session.get("pendingFavorite").then(({ pendingFavorite }) => consumePendingFavorite(pendingFavorite));

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "session" && changes.pendingLookup?.newValue) {
    consumePending(changes.pendingLookup.newValue);
    return;
  }
  if (area === "session" && changes.pendingFavorite?.newValue) {
    consumePendingFavorite(changes.pendingFavorite.newValue);
    return;
  }
  if (area !== "local") return;
  if (changes.favorites) {
    state.favorites = changes.favorites.newValue || {};
    if (state.activeWord === state.noteDraftWord && !state.noteDirty) {
      state.noteDraft = state.favorites[state.activeWord]?.note || "";
    }
    for (const key of state.selected) if (!Object.hasOwn(state.favorites, key)) state.selected.delete(key);
    if (state.activeWord && !Object.hasOwn(state.favorites, state.activeWord)
        && matcher.keyFor(state.lookupEntry?.text) !== state.activeWord) state.activeWord = null;
    render();
  }
  if (changes.pausedSites) {
    state.pausedSites = changes.pausedSites.newValue || {};
    renderPausedSites();
    renderPageSetting();
  }
  if (changes.disabledSelectionPages) {
    state.disabledSelectionPages = changes.disabledSelectionPages.newValue || {};
    renderPageSetting();
    renderDisabledPages();
  }
  if (changes.autoTranslateChinese) {
    state.autoTranslateChinese = Boolean(changes.autoTranslateChinese.newValue);
    $("#auto-chinese").checked = state.autoTranslateChinese;
  }
  if (changes.fontSize) applyFontSize(changes.fontSize.newValue);
});

chrome.tabs.onActivated?.addListener(() => {
  if (state.settingsOpen) refreshCurrentPageSetting();
});
chrome.tabs.onUpdated?.addListener(() => {
  if (state.settingsOpen) refreshCurrentPageSetting();
});

$("#auto-chinese").addEventListener("change", async (event) => {
  try { await chrome.storage.local.set({ autoTranslateChinese: event.target.checked }); }
  catch (error) { toast(error.message); event.target.checked = state.autoTranslateChinese; }
});

function applyFontSize(value) {
  const size = Number(value);
  state.fontSize = FONT_SIZES.has(size) ? size : 100;
  document.documentElement.style.setProperty("--font-scale", String(state.fontSize / 100));
  $("#font-size").value = String(state.fontSize);
}

$("#font-size").addEventListener("change", async (event) => {
  const previous = state.fontSize;
  applyFontSize(event.target.value);
  try { await chrome.storage.local.set({ fontSize: state.fontSize }); }
  catch (error) { applyFontSize(previous); toast(error.message); }
});

async function getActivePageContext() {
  const windowId = await windowIdPromise;
  const query = windowId === null ? { active: true, currentWindow: true } : { active: true, windowId };
  const [tab] = await chrome.tabs.query(query);
  if (!Number.isInteger(tab?.id)) throw new Error("当前标签页不可用");
  const page = await chrome.tabs.sendMessage(tab.id, { type: "GET_PAGE_CONTEXT" }, { frameId: 0 });
  const key = matcher.pageKeyFor(page?.url);
  if (!key) throw new Error("此页面不支持自动划词设置");
  return key;
}

function renderPageSetting() {
  const key = state.currentPageKey;
  const checkbox = $("#page-auto-translate");
  const status = $("#page-auto-translate-status");
  if (!key) {
    checkbox.disabled = true;
    status.textContent = "当前网页不可用，请在普通网页刷新后重试。";
    return;
  }
  const pausedSite = Boolean(state.pausedSites[new URL(key).hostname]);
  checkbox.checked = !pausedSite && !Boolean(state.disabledSelectionPages[key]);
  checkbox.disabled = pausedSite;
  status.textContent = pausedSite
    ? "此网站已设置弹窗静默，高亮仍开启。可在下方恢复网站弹窗。"
    : "当前网页：" + key.replace(/^https?:\/\//, "");
}

function renderDisabledPages() {
  const keys = Object.keys(state.disabledSelectionPages).filter((key) => state.disabledSelectionPages[key]).sort();
  $("#disabled-pages-count").textContent = keys.length ? "(" + keys.length + ")" : "";
  const list = $("#disabled-pages-list");
  list.replaceChildren();
  if (!keys.length) {
    const empty = document.createElement("p");
    empty.textContent = "暂无关闭弹窗的网页。";
    list.append(empty);
    return;
  }
  for (const key of keys) {
    const row = document.createElement("div");
    row.className = "paused-site-row";
    const label = document.createElement("span");
    label.textContent = key.replace(/^https?:\/\//, "");
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "恢复";
    button.addEventListener("click", async () => {
      button.disabled = true;
      try {
        const disabledSelectionPages = { ...state.disabledSelectionPages };
        delete disabledSelectionPages[key];
        await chrome.storage.local.set({ disabledSelectionPages });
      } catch (error) { toast(error.message); button.disabled = false; }
    });
    row.append(label, button);
    list.append(row);
  }
}

async function refreshCurrentPageSetting() {
  const version = ++pageContextVersion;
  state.currentPageKey = "";
  $("#page-auto-translate").disabled = true;
  $("#page-auto-translate-status").textContent = "正在识别当前网页…";
  try {
    const key = await getActivePageContext();
    if (version !== pageContextVersion || !state.settingsOpen) return;
    state.currentPageKey = key;
    renderPageSetting();
  } catch {
    if (version !== pageContextVersion || !state.settingsOpen) return;
    renderPageSetting();
  }
}

$("#page-auto-translate").addEventListener("change", async (event) => {
  const key = state.currentPageKey;
  if (!key) return;
  const checkbox = event.target;
  checkbox.disabled = true;
  try {
    if (await getActivePageContext() !== key) {
      refreshCurrentPageSetting();
      throw new Error("当前网页已切换，请重试");
    }
    const disabledSelectionPages = { ...state.disabledSelectionPages };
    if (checkbox.checked) delete disabledSelectionPages[key];
    else disabledSelectionPages[key] = true;
    await chrome.storage.local.set({ disabledSelectionPages });
    state.disabledSelectionPages = disabledSelectionPages;
    renderPageSetting();
  } catch (error) {
    checkbox.checked = !Boolean(state.disabledSelectionPages[key]);
    toast(error.message);
    renderPageSetting();
  }
});

async function consumePending(pending) {
  if (!pending?.id || pending.id === lastPendingId) return;
  const currentWindowId = await windowIdPromise;
  if (currentWindowId !== null && pending.windowId !== undefined && pending.windowId !== currentWindowId) return;
  lastPendingId = pending.id;
  chrome.storage.session.remove("pendingLookup").catch(() => {});
  $("#lookup-input").value = pending.text || "";
  if (pending.tooLong) {
    toast("选中内容超过 500 字，请缩短后再翻译");
    return;
  }
  startLookup(pending.text || "");
}

let lastPendingFavoriteId = "";
async function consumePendingFavorite(pending) {
  if (!pending?.id || pending.id === lastPendingFavoriteId) return;
  const currentWindowId = await windowIdPromise;
  if (currentWindowId !== null && pending.windowId !== undefined && pending.windowId !== currentWindowId) return;
  lastPendingFavoriteId = pending.id;
  chrome.storage.session.remove("pendingFavorite").catch(() => {});
  await favoritesReady;
  const key = matcher.keyFor(pending.key);
  if (!Object.hasOwn(state.favorites, key)) {
    toast("这条收藏已被删除");
    return;
  }
  lookupVersion++;
  state.activeWord = null;
  state.lookupEntry = null;
  state.settingsOpen = false;
  state.search = "";
  state.selecting = false;
  state.selected.clear();
  state.locatedFavorite = key;
  $("#search").value = "";
  render();
}

$("#search").addEventListener("input", (event) => {
  state.search = event.target.value.trim().toLowerCase();
  state.locatedFavorite = null;
  renderList();
});

$("#lookup-input").addEventListener("keydown", (event) => {
  if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
    event.preventDefault();
    $("#lookup-form").requestSubmit();
  }
});

$("#lookup-form").addEventListener("submit", (event) => {
  event.preventDefault();
  startLookup($("#lookup-input").value);
});

$("#open-pdf-reader").addEventListener("click", async () => {
  try { await chrome.tabs.create({ url: chrome.runtime.getURL("pdf-reader.html") }); }
  catch (error) { toast(error.message || "无法打开 PDF 阅读器"); }
});

function startLookup(rawText) {
  const text = matcher.normalizeQuery(rawText);
  if (!text) {
    toast("请输入不超过 500 字的英文或中文内容");
    return;
  }
  const key = matcher.keyFor(text);
  state.settingsOpen = false;
  state.locatedFavorite = null;
  const version = ++lookupVersion;
  const saved = Object.hasOwn(state.favorites, key) ? state.favorites[key] : null;
  const needsTranslation = !saved?.meaning;
  const word = matcher.normalizeWord(text);
  state.activeWord = key;
  state.noteDraftWord = key;
  state.noteDraft = saved?.note || "";
  state.noteDirty = false;
  state.lookupEntry = saved ? null : { text, word: text, meaning: "", phonetic: "", definition: "", examples: [], localSenses: [], dictionarySenses: [], audio: [], direction: matcher.directionFor(text) };
  state.pendingTranslation = needsTranslation;
  state.pendingDetails = Boolean(word && !saved?.dictionarySenses?.length);
  state.lookupError = "";
  state.corpusExamples = [];
  closeEdit();
  render();

  if (needsTranslation) {
    lookupWithFallback(text).then((entry) => {
      if (version !== lookupVersion) return;
      state.lookupEntry = { ...state.lookupEntry, ...entry,
        phonetic: state.lookupEntry?.phonetic || entry.phonetic || "",
        definition: state.lookupEntry?.definition || entry.definition || "",
        examples: state.lookupEntry?.examples?.length ? state.lookupEntry.examples : entry.examples || [],
        localSenses: state.lookupEntry?.localSenses?.length ? state.lookupEntry.localSenses : entry.localSenses || [],
        localHeadword: state.lookupEntry?.localHeadword || entry.localHeadword || "",
        dictionarySenses: state.lookupEntry?.dictionarySenses?.length ? state.lookupEntry.dictionarySenses : entry.dictionarySenses || [],
        audio: state.lookupEntry?.audio?.length ? state.lookupEntry.audio : entry.audio || [] };
      state.pendingTranslation = false;
      state.lookupError = "";
      renderDetail();
      enrichIfSaved();
    }).catch((error) => {
      if (version !== lookupVersion) return;
      state.pendingTranslation = false;
      state.lookupError = error.message;
      renderDetail();
    });
  }

  if (word && !saved?.localSenses?.length) {
    send({ type: "LOCAL_WORD_DETAILS", word }).then((details) => {
      if (version !== lookupVersion || !details) return;
      state.lookupEntry = {
        ...(state.lookupEntry || { text, word: text }),
        phonetic: state.lookupEntry?.phonetic || details.phonetic,
        localSenses: details.localSenses || [], localHeadword: details.localHeadword || ""
      };
      renderDetail();
      enrichIfSaved();
    }).catch(() => {});
  }

  if (state.pendingDetails) {
    send({ type: "WORD_DETAILS", word }).then((details) => {
      if (version !== lookupVersion) return;
      state.lookupEntry = { ...(state.lookupEntry || { text, word: text }), ...details };
      state.pendingDetails = false;
      renderDetail();
      enrichIfSaved();
    }).catch(() => {
      if (version !== lookupVersion) return;
      state.pendingDetails = false;
      renderDetail();
    });
  }

  if (word) {
    send({ type: "EXAMPLE_SENTENCES", word }).then((examples) => {
      if (version !== lookupVersion) return;
      state.corpusExamples = Array.isArray(examples) ? examples : [];
      renderCorpusExamples();
    }).catch(() => {
      if (version !== lookupVersion) return;
      state.corpusExamples = [];
      renderCorpusExamples();
    });
  }
}

function enrichIfSaved() {
  const entry = getActiveEntry();
  if (entry && Object.hasOwn(state.favorites, state.activeWord)) {
    send({ type: "ENRICH_FAVORITE", entry }).catch(() => {});
  }
}

$("#select-toggle").addEventListener("click", () => {
  state.selecting = !state.selecting;
  state.selected.clear();
  renderList();
});

$("#select-all").addEventListener("click", () => {
  const visible = getVisibleKeys();
  if (visible.every((key) => state.selected.has(key))) {
    for (const key of visible) state.selected.delete(key);
  } else {
    for (const key of visible) state.selected.add(key);
  }
  renderList();
});

$("#delete").addEventListener("click", async () => {
  const keys = [...state.selected];
  if (!keys.length || !confirm(`删除选中的 ${keys.length} 条收藏？`)) return;
  try {
    await send({ type: "DELETE_FAVORITES", words: keys });
    state.selected.clear();
    state.selecting = false;
    renderList();
    toast(`已删除 ${keys.length} 条收藏`);
  } catch (error) { toast(error.message); }
});

$("#export").addEventListener("click", exportCsv);
$("#open-settings").addEventListener("click", () => {
  state.settingsOpen = true;
  render();
  refreshCurrentPageSetting();
});
$("#settings-back").addEventListener("click", () => {
  pageContextVersion++;
  state.settingsOpen = false;
  state.currentPageKey = "";
  render();
});
$("#back").addEventListener("click", () => {
  lookupVersion++;
  state.activeWord = null;
  state.lookupEntry = null;
  render();
});
$("#detail-speak").addEventListener("click", () => {
  const entry = getActiveEntry();
  if (entry) speak(entry.text || entry.word, entry.audio);
});
$("#detail-save").addEventListener("click", async () => {
  const key = state.activeWord;
  const entry = getActiveEntry();
  if (!key || !entry || Object.hasOwn(state.favorites, key)) return;
  const button = $("#detail-save");
  button.disabled = true;
  try {
    const result = await send({ type: "TOGGLE_FAVORITE", entry });
    if (result.saved) Object.defineProperty(state.favorites, key, { value: result.entry, enumerable: true, configurable: true, writable: true });
    toast(result.saved ? "已加入收藏夹" : "收藏失败，请重试");
    render();
  } catch (error) { toast(error.message); }
  finally { button.disabled = Object.hasOwn(state.favorites, key); }
});
$("#detail-delete").addEventListener("click", async () => {
  const key = state.activeWord;
  if (!key || !Object.hasOwn(state.favorites, key)) return;
  const display = state.favorites[key].text || state.favorites[key].word || key;
  if (!confirm(`确定删除“${display}”？`)) return;
  const button = $("#detail-delete");
  button.disabled = true;
  try {
    await send({ type: "DELETE_FAVORITES", words: [key] });
    delete state.favorites[key];
    state.selected.delete(key);
    if (state.locatedFavorite === key) state.locatedFavorite = null;
    state.activeWord = null;
    state.lookupEntry = null;
    state.noteDraftWord = null;
    state.noteDirty = false;
    lookupVersion++;
    render();
    toast(`已删除 ${display}`);
  } catch (error) { toast(error.message); }
  finally { button.disabled = false; }
});
$("#edit-meaning").addEventListener("click", () => {
  $("#meaning-input").value = getActiveEntry()?.meaning || "";
  $("#meaning-form").hidden = false;
  $("#edit-meaning").hidden = true;
  $("#meaning-input").focus();
});
$("#cancel-edit").addEventListener("click", closeEdit);
$("#meaning-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    await send({ type: "UPDATE_MEANING", word: state.activeWord, meaning: $("#meaning-input").value });
    closeEdit();
    toast("译文已保存");
  } catch (error) { toast(error.message); }
});
$("#save-note").addEventListener("click", async () => {
  if (!state.activeWord || !Object.hasOwn(state.favorites, state.activeWord)) return;
  const button = $("#save-note");
  const word = state.activeWord;
  const note = $("#note-input").value;
  button.disabled = true;
  try {
    await send({ type: "UPDATE_NOTE", word, note });
    if (state.noteDraftWord === word && state.noteDraft === note) state.noteDirty = false;
    toast("笔记已保存");
  } catch (error) { toast(error.message); }
  finally { button.disabled = false; }
});
$("#note-input").addEventListener("input", (event) => {
  state.noteDraftWord = state.activeWord;
  state.noteDraft = event.target.value;
  state.noteDirty = true;
});

function closeEdit() {
  $("#meaning-form").hidden = true;
  $("#edit-meaning").hidden = false;
}

function getVisibleKeys() {
  return Object.keys(state.favorites)
    .filter((key) => {
      const entry = state.favorites[key];
      return !state.search || key.includes(state.search)
        || (entry.text || entry.word || "").toLowerCase().includes(state.search)
        || (entry.meaning || "").toLowerCase().includes(state.search)
        || (entry.note || "").toLowerCase().includes(state.search);
    })
    .sort((a, b) => (state.favorites[b].savedAt || 0) - (state.favorites[a].savedAt || 0) || a.localeCompare(b));
}

function render() {
  const view = state.settingsOpen ? "settings" : state.activeWord ? "detail" : "list";
  $("#count").textContent = `${Object.keys(state.favorites).length} 条收藏`;
  $("#count").hidden = view !== "list";
  $("#open-settings").hidden = view !== "list";
  $("#page-title").textContent = view === "settings" ? "设置" : "我的收藏夹";
  $("#list-view").hidden = view !== "list";
  $("#settings-view").hidden = view !== "settings";
  $("#detail-view").hidden = view !== "detail";
  if (view === "detail") renderDetail();
  else if (view === "settings") {
    renderPausedSites();
    renderDisabledPages();
    renderPageSetting();
  }
  else renderList();
}

function renderList() {
  renderPausedSites();
  const keys = getVisibleKeys();
  const list = $("#list");
  list.replaceChildren();
  $("#select-toggle").textContent = state.selecting ? "完成" : "多选";
  $("#select-all").hidden = !state.selecting || !keys.length;
  $("#select-all").textContent = keys.length && keys.every((key) => state.selected.has(key)) ? "取消全选" : "全选";
  $("#delete").disabled = !state.selected.size;
  $("#delete").textContent = state.selected.size ? `删除 (${state.selected.size})` : "删除";
  $("#export").disabled = !Object.keys(state.favorites).length;
  $("#selection-count").hidden = !state.selecting;
  $("#selection-count").textContent = `已选 ${state.selected.size} 条`;

  for (const key of keys) {
    const entry = state.favorites[key];
    const display = entry.text || entry.word || key;
    const row = document.createElement("div");
    row.className = `word-row${state.selected.has(key) ? " selected" : ""}${state.locatedFavorite === key ? " located" : ""}`;
    if (state.selecting) {
      const check = document.createElement("input");
      check.type = "checkbox";
      check.className = "row-check";
      check.checked = state.selected.has(key);
      check.setAttribute("aria-label", `选择 ${display}`);
      check.addEventListener("change", () => toggleSelected(key));
      row.append(check);
    }
    const open = document.createElement("button");
    open.type = "button";
    open.className = "row-open";
    const title = document.createElement("span");
    title.className = "row-word";
    title.textContent = display;
    const meaning = document.createElement("span");
    meaning.className = "row-meaning";
    meaning.textContent = entry.meaning || "点击补充译文";
    open.append(title, meaning);
    open.addEventListener("click", () => {
      if (state.selecting) toggleSelected(key);
      else startLookup(display);
    });
    const speakButton = document.createElement("button");
    speakButton.type = "button";
    speakButton.className = "speak";
    speakButton.textContent = "♪";
    speakButton.title = `朗读 ${display}`;
    speakButton.setAttribute("aria-label", speakButton.title);
    speakButton.addEventListener("click", () => speak(display, entry.audio));
    row.append(open, speakButton);
    list.append(row);
    if (state.locatedFavorite === key) {
      setTimeout(() => {
        if (state.locatedFavorite !== key) return;
        row.scrollIntoView?.({ block: "center", behavior: "smooth" });
        open.focus({ preventScroll: true });
      }, 100);
    }
  }
  $("#empty").hidden = Boolean(keys.length);
  const any = Object.keys(state.favorites).length > 0;
  $("#empty-title").textContent = any ? "没有找到匹配的内容" : "还没有收藏内容";
  $("#empty-message").textContent = any ? "试试其他文字或译文。" : "划选网页文字、右键翻译，或在上方输入内容后收藏。";
}

function renderPausedSites() {
  const hosts = Object.keys(state.pausedSites).filter((host) => state.pausedSites[host]).sort();
  $("#paused-count").textContent = hosts.length ? `(${hosts.length})` : "";
  const list = $("#paused-sites-list");
  list.replaceChildren();
  if (!hosts.length) {
    const empty = document.createElement("p");
    empty.textContent = "暂无静默的网站。";
    list.append(empty);
    return;
  }
  for (const host of hosts) {
    const row = document.createElement("div");
    row.className = "paused-site-row";
    const label = document.createElement("span");
    label.textContent = host;
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "恢复";
    button.addEventListener("click", async () => {
      button.disabled = true;
      try { await send({ type: "RESUME_SITE", hostname: host }); }
      catch (error) { toast(error.message); button.disabled = false; }
    });
    row.append(label, button);
    list.append(row);
  }
}

function toggleSelected(key) {
  if (state.selected.has(key)) state.selected.delete(key);
  else state.selected.add(key);
  renderList();
}

function getActiveEntry() {
  const key = state.activeWord;
  if (!key) return null;
  const saved = Object.hasOwn(state.favorites, key) ? state.favorites[key] : null;
  const lookup = matcher.keyFor(state.lookupEntry?.text) === key ? state.lookupEntry : null;
  if (!saved && !lookup) return null;
  const base = saved || lookup;
  return {
    ...base,
    text: base.text || base.word || key,
    word: base.word || base.text || key,
    meaning: saved?.meaning || lookup?.meaning || "",
    phonetic: lookup?.phonetic || saved?.phonetic || "",
    definition: lookup?.definition || saved?.definition || "",
    examples: [...new Set([...(saved?.examples || []), ...(lookup?.examples || [])])].slice(0, 12),
    localSenses: lookup?.localSenses?.length ? lookup.localSenses : saved?.localSenses || [],
    localHeadword: lookup?.localHeadword || saved?.localHeadword || "",
    dictionarySenses: lookup?.dictionarySenses?.length ? lookup.dictionarySenses : saved?.dictionarySenses || [],
    audio: lookup?.audio?.length ? lookup.audio : saved?.audio || [],
    note: saved?.note || "",
    direction: base.direction || matcher.directionFor(base.text || key)
  };
}

function renderDetail() {
  if (!state.activeWord) return;
  const entry = getActiveEntry();
  if (!entry) { state.activeWord = null; render(); return; }
  const saved = Object.hasOwn(state.favorites, state.activeWord);
  const display = entry.text || entry.word;
  const isWord = Boolean(matcher.normalizeWord(display));
  const hasLocalSenses = isWord && matcher.groupSenses(entry.localSenses).length > 0;
  $("#detail-label").textContent = saved ? (isWord ? "收藏单词" : "收藏词句") : "翻译结果";
  $("#detail-word").textContent = display;
  $("#detail-word").classList.toggle("long-text", display.length > 25 || display.includes(" "));
  $("#detail-phonetic").textContent = entry.phonetic || "";
  $("#detail-phonetic").hidden = !entry.phonetic;
  renderAudioOptions(entry);
  $("#detail-meaning").textContent = entry.meaning || (state.pendingTranslation ? "正在翻译…" : "暂无译文，可收藏后编辑");
  $("#translation-section").hidden = hasLocalSenses;
  $("#detail-definition").textContent = entry.definition || "";
  $("#detail-definition").hidden = !entry.definition || Boolean(entry.dictionarySenses?.length);
  const status = state.lookupError && !entry.meaning ? state.lookupError
    : state.pendingTranslation ? "正在翻译…"
    : state.pendingDetails ? "正在补充英英释义和发音…" : "";
  $("#detail-status").textContent = status;
  $("#detail-status").hidden = !status;
  $("#detail-save").textContent = saved ? "★ 已收藏" : "☆ 收藏内容";
  $("#detail-save").classList.toggle("saved", saved);
  $("#detail-save").disabled = saved;
  $("#detail-delete").hidden = !saved;
  if (!saved || hasLocalSenses) closeEdit();
  $("#edit-meaning").hidden = !saved || !$("#meaning-form").hidden;
  $("#note-input").disabled = !saved;
  $("#save-note").disabled = !saved;
  $("#note-hint").hidden = saved;
  if (state.noteDraftWord !== state.activeWord) {
    state.noteDraftWord = state.activeWord;
    state.noteDraft = entry.note || "";
    state.noteDirty = false;
  }
  $("#note-input").value = state.noteDraft;
  renderSenses(entry);
  showExamples(entry.examples || []);
  renderCorpusExamples();
}

function renderAudioOptions(entry) {
  const container = $("#audio-options");
  container.replaceChildren();
  const display = entry.text || entry.word;
  for (const [index, url] of (entry.audio || []).entries()) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = `词典发音 ${index + 1}`;
    button.addEventListener("click", () => new Audio(url).play().catch(() => speakWithBrowser(display)));
    container.append(button);
  }
  const browser = document.createElement("button");
  browser.type = "button";
  browser.textContent = "浏览器朗读";
  browser.addEventListener("click", () => speakWithBrowser(display));
  container.append(browser);
}

function renderSenses(entry) {
  const local = matcher.groupSenses(entry.localSenses);
  $("#local-senses-section").hidden = !local.length;
  const localContainer = $("#local-senses");
  localContainer.replaceChildren();
  if (local.length && entry.localHeadword && entry.localHeadword !== matcher.normalizeWord(entry.text)) {
    const origin = document.createElement("p");
    origin.className = "sense-origin";
    origin.textContent = `以下释义参考原形 ${entry.localHeadword}`;
    localContainer.append(origin);
  }
  for (const group of local) {
    const section = document.createElement("div");
    section.className = "sense-group local-sense-group";
    const pos = document.createElement("span");
    pos.className = "sense-pos";
    pos.textContent = matcher.partOfSpeechLabel(group.partOfSpeech);
    const meanings = document.createElement("p");
    meanings.className = "sense-inline";
    meanings.textContent = (group.meanings || []).join("；");
    section.append(pos, meanings);
    localContainer.append(section);
  }
  const dictionary = entry.dictionarySenses || [];
  $("#dictionary-senses-section").hidden = !dictionary.length;
  const dictionaryContainer = $("#dictionary-senses");
  dictionaryContainer.replaceChildren();
  for (const group of dictionary) {
    const section = document.createElement("div");
    section.className = "sense-group";
    const pos = document.createElement("span");
    pos.className = "sense-pos";
    pos.textContent = group.partOfSpeech || "其他";
    const list = document.createElement("ol");
    list.className = "sense-items";
    for (const definition of group.definitions || []) {
      const item = document.createElement("li");
      item.textContent = definition.definition;
      if (definition.example) {
        const example = document.createElement("span");
        example.className = "sense-example";
        example.textContent = definition.example;
        item.append(example);
      }
      list.append(item);
    }
    section.append(pos, list);
    dictionaryContainer.append(section);
  }
}

function showExamples(examples) {
  const container = $("#examples");
  container.replaceChildren();
  $("#examples-heading").hidden = !examples.length;
  $("#example-count").textContent = `${examples.length} 条`;
  for (const example of examples) {
    const item = document.createElement("div");
    item.className = "example";
    item.textContent = example;
    container.append(item);
  }
}

function renderCorpusExamples() {
  const isWord = Boolean(matcher.normalizeWord(getActiveEntry()?.text));
  const examples = matcher.dedupeBilingualExamples(state.corpusExamples);
  $("#corpus-heading").hidden = !isWord || !examples.length;
  const list = $("#corpus-examples");
  list.replaceChildren();
  if (!isWord) return;
  for (const example of examples) {
    const item = document.createElement("div");
    item.className = "example";
    const original = document.createElement("div");
    original.textContent = example.text;
    const translation = document.createElement("p");
    translation.className = "example-translation";
    translation.textContent = example.translation;
    const source = document.createElement("a");
    source.className = "example-source";
    source.href = `https://tatoeba.org/en/sentences/show/${example.id}`;
    source.target = "_blank";
    source.rel = "noopener noreferrer";
    const licenses = [...new Set([example.license, example.translationLicense].filter(Boolean))].join(" / ");
    source.textContent = `Tatoeba · ${example.author || "匿名"} / ${example.translationAuthor || "匿名"} · ${licenses || "开放许可"}`;
    item.append(original, translation, source);
    list.append(item);
  }
}

function exportCsv() {
  const keys = Object.keys(state.favorites).sort((a, b) => a.localeCompare(b));
  if (!keys.length) return;
  const quote = (value) => {
    const safe = String(value ?? "").replace(/^[=+\-@\t\r]/, (prefix) => `'${prefix}`);
    return `"${safe.replaceAll('"', '""')}"`;
  };
  const rows = [["原文", "译文", "音标", "例句", "笔记", "收藏时间"]];
  for (const key of keys) {
    const entry = state.favorites[key];
    rows.push([entry.text || entry.word || key, entry.meaning || "", entry.phonetic || "", (entry.examples || []).join(" | "), entry.note || "", entry.savedAt ? new Date(entry.savedAt).toLocaleString("zh-CN") : ""]);
  }
  const csv = "\uFEFF" + rows.map((row) => row.map(quote).join(",")).join("\r\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = `词芽收藏夹-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
  toast(`已导出 ${keys.length} 条收藏`);
}

function speak(text, audioUrls = []) {
  if (!text) return;
  if (audioUrls?.length) {
    new Audio(audioUrls[0]).play().catch(() => speakWithBrowser(text));
    return;
  }
  speakWithBrowser(text);
}

function speakWithBrowser(text) {
  if (!globalThis.speechSynthesis) return;
  speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = matcher.directionFor(text) === "zh-CN|en" ? "zh-CN" : "en-US";
  utterance.rate = 0.85;
  speechSynthesis.speak(utterance);
}

function toast(message) {
  const element = $("#toast");
  element.textContent = message;
  element.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { element.hidden = true; }, 2800);
}

async function send(message) {
  const response = await chrome.runtime.sendMessage(message);
  if (!response?.ok) {
    const error = new Error(response?.error || "操作失败");
    error.code = response?.code;
    throw error;
  }
  return response.data;
}

async function lookupWithFallback(text) {
  try { return await send({ type: "LOOKUP", text }); }
  catch (error) {
    if (error.code !== "TRANSLATION_RATE_LIMIT") throw error;
    const meaning = await globalThis.WordSproutBrowserTranslate?.translate(text, matcher.directionFor(text));
    if (!meaning) throw error;
    send({ type: "CACHE_TRANSLATION", text, meaning }).catch(() => {});
    return { text, word: text, meaning, direction: matcher.directionFor(text) };
  }
}

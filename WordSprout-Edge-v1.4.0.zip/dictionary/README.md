# ECDICT compact index

The 26 JSON shards in this directory were generated from the [ECDICT English–Chinese dictionary](https://github.com/skywind3000/ECDICT) with `node tools/build-dictionary.js ecdict-source.csv`.

- Source file: `ecdict.csv` from the ECDICT `master` branch, downloaded 2026-10-08.
- Source SHA-256: `1A6947E04785DB63613A92E14903CDAE7954F7E84860B10E68E5C7CBB3F9C3CF`.
- This compact index includes 50,000 ranked alphabetic headwords. It preserves ECDICT's Chinese translation groups and phonetics. It omits the remaining source entries to keep the extension small. It also includes the manually reviewed `monsoonal` → “季风的” supplement.
- License: MIT; see [ECDICT-LICENSE.txt](ECDICT-LICENSE.txt).

The original CSV is only needed to regenerate these shards and is not shipped with the extension.

# 词芽 · WordSprout

一个可直接加载到 Microsoft Edge 的 Manifest V3 英语学习扩展。划选网页文字或在侧边栏输入内容，可在线翻译单词、词组和句子。翻译结果都能收藏；单个英文单词还会在当前和以后访问的网页中自动高亮常见词形。

## 安装

1. 在 Edge 地址栏打开 `edge://extensions`，开启「开发人员模式」。
2. 点击「加载解压缩的扩展」，选择本项目文件夹（包含 `manifest.json` 的目录）。
3. 打开普通网页，划选英文单词、词组或句子，即可在旁边查看译文。中文划选默认不自动弹卡，仍可右键选择「用词芽翻译选中内容」，或点击工具栏中的词芽图标在侧边栏手动翻译。

修改源码后，在 `edge://extensions` 中点击扩展卡片上的「重新加载」，并刷新已经打开的网页。

### PDF 划词

Edge 自带的 PDF 阅读页与普通网页不同，词芽卡片无法直接注入其中；右键菜单也可能不显示扩展项目。点击工具栏词芽图标，在侧边栏收藏夹操作栏选择「阅读 PDF」，再选择本地 PDF 文件或拖入文件。词芽会在新标签页渲染可选择的文字层，划选后显示翻译卡片；在这个阅读页右键选中文字也可尝试「用词芽翻译选中内容」。文件在本机解析，不上传到翻译接口；划选查询的文字按下方「数据来源」说明发送给在线服务。扫描版 PDF 若没有文字层，需要先经过 OCR 才能划词。

## 功能

- 常见英文单词优先从随扩展附带的精简 ECDICT 词库读取多词性中文释义；`performed` 等常见词形可回查 `perform` 等原形。词组、句子和词库未收录的单词使用在线翻译；在线服务限流时，若 Edge 支持则尝试浏览器本机翻译（首次可能需要下载模型）。以中文开头的内容翻译为英文。每次最多 500 个字符；较长中文内容按在线接口的单次字节限制分段翻译。
- 划词卡片按词性展示最多三条去重后的简明义项，并逐步补充音标、读音和一条例句；卡片底部保留收藏与收藏夹，已收藏笔记也会显示。侧边栏按词性用分号排列内置词库收录的中文释义组，并展示公开词典提供的英英释义、例句和发音。词典原声不可用时使用浏览器朗读。
- 侧边栏另外查找带中文译文的 Tatoeba 开放语料例句，逐条显示来源和许可。开放语料例句不一定对应当前选中的某一个义项。
- 右键选中文字会直接打开侧边栏显示结果，不依赖网页内容脚本收到消息；侧边栏也能手动输入或粘贴内容翻译。
- 单词、词组和句子均可收藏、朗读、编辑译文、记录笔记；单条删除位于收藏详情页，首页支持多选删除和导出带 BOM 的 CSV（Excel 可直接打开）。
- 在划词卡片点击「Ⅱ」可关闭当前网页的自动划词弹卡；侧边栏「设置」中的当前网页开关或「管理关闭弹窗的网页」列表可重新开启。此开关保留收藏高亮，不影响右键查词和侧边栏手动查询。中文自动划词也可在设置中单独开启；旧版暂停网站的记录现在也只静默弹窗，可在「管理静默的网站」中恢复弹窗。
- 已收藏英文单词和词组在网页正文中自动高亮，忽略大小写；单词按完整词形匹配并支持常见复数、过去式、进行时和部分派生词，例如收藏 `develop` 后会高亮 `Develop`、`developing` 和 `development`。点击高亮内容会打开侧边栏并定位到对应收藏条目。
- 收藏夹、成功查到的译文缓存和逐页关闭弹卡的设置使用 `chrome.storage.local` 保存在本机浏览器中。

## 数据来源与使用范围

在线翻译时，待翻译文字会发送给 [MyMemory Translation API](https://mymemory.translated.net/doc/spec.php)；点击卡片中的「翻译本页句子」时，该句也会发送给 MyMemory。限流回退使用 [Edge Translator API](https://learn.microsoft.com/en-us/microsoft-edge/web-platform/translator-api) 在本机处理文字。查询单个英文单词时，会将该单词发送给 [Free Dictionary API](https://dictionaryapi.dev/) 和 [Tatoeba](https://api.tatoeba.org/) 获取公开词典信息与双语例句。常用词的中文释义来自扩展内置的 [ECDICT 精简索引](dictionary/README.md)，按 MIT 许可使用。收藏夹、笔记及网页弹卡设置保存在本机浏览器中，不上传。在线服务需要联网；公开词典和语料并不能保证每个词都有完整音频或例句，也不等同于有道或牛津的授权词典内容。

扩展只自动注入 `http://` 和 `https://` 网页；Edge 设置页、扩展商店、自带 PDF 阅读器等浏览器内部页面无法划词高亮。词芽 PDF 阅读页可以划词，但为了保持 PDF 文字层的位置，不对 PDF 正文执行自动高亮。网页表单、可编辑区域及代码块不会高亮，避免影响输入和代码阅读。

PDF 阅读器随扩展打包 [Mozilla PDF.js](https://mozilla.github.io/pdf.js/) 6.3.289，采用 Apache-2.0 许可，许可文本及所需字库文件保存在 `vendor/package/`。其阅读页支持本地文件、翻页和缩放；浏览器原生 PDF 批注功能不属于词芽阅读页。

## 开发检查

无需安装依赖或构建工具。使用 Node.js 运行：

```sh
node tests/matcher.test.js
node tests/background.test.js
node tests/content.test.js
node tests/pdf-reader.test.js
node tests/ui-static.test.js
node tests/sidepanel.test.js
```

Edge 侧边栏设置依据 [Microsoft Edge 扩展文档](https://learn.microsoft.com/en-us/microsoft-edge/extensions/developer-guide/sidebar)。
